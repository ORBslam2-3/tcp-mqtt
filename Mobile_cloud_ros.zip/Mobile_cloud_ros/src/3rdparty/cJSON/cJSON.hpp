#ifndef JSON3_HPP_INCLUDE
#define JSON3_HPP_INCLUDE

#include <string>
#include <string.h>
#include <unistd.h>
#include <typeinfo>
#include "cJSON.h"
///////////////////////////////////////////////////////
class CJSON3
{
public:
    CJSON3() {};
    virtual ~CJSON3() {};
    static void PrintEnvironment() {
        char dir[255] = {'\0'};
        getcwd(dir, sizeof(dir));
        printf("CJSON3: current dir: %s", dir);
    }

    static cJSON* Load(const char* str, bool is_JSON_FILE = true) {
        if (is_JSON_FILE) {
            cJSON* root = NULL;
            FILE* fpr = fopen(str, "r");
            if (fpr != NULL) {
                fseek(fpr, 0, SEEK_END);
                long len = ftell(fpr);
                if (len > 0) {
                    rewind(fpr);
                    char* buf = (char*)malloc(len + 1);
                    if (buf != NULL) {
                        size_t n = fread(buf, len, 1, fpr);
                        if (n == 1) {
                            root = cJSON_Parse(buf);
                        } free(buf);
                    }
                } fclose(fpr);
            }
            return root;
        } else {
            return cJSON_Parse(str);
        }
    }

    static std::string FileGet(const std::string& filePath) {
        std::string result;
        FILE* fpr = fopen(filePath.c_str(), "r");
        if (fpr != NULL) {
            fseek(fpr, 0, SEEK_END);
            long len = ftell(fpr);
            if (len > 0) {
                rewind(fpr);
                result.resize(len + 1);
                if (!fread((char*)result.c_str(), len, 1, fpr)) {
                    result.clear();
                }
            } fclose(fpr);
        }
        return result;
    }

    static cJSON* Route(const cJSON* parent, const std::string& route) {
        // 多级路由: 路径由"/"分隔
        cJSON* child = parent->child;
        std::string temp = route.c_str();
        char* token = strtok((char*)temp.c_str(), "/");
        while (child && token) {
            if (child->string && !strcasecmp(child->string, token)) {
                token = strtok(NULL, "/");
                if (token) {
                    child = child->child;
                } else {
                    break;
                }
            } else {
                child = child->next;
            }
        }

        return child;
    }

    // 判断节点是否存在(第三个参数：大写小是否敏感)
    static bool Exist(const cJSON* parent, const std::string& name, bool case_sensitive = false) {
        cJSON* result = NULL;
        if (case_sensitive) {
            result = cJSON_GetObjectItemCaseSensitive(parent, name.c_str());
        } else {
            result = cJSON_GetObjectItem(parent, name.c_str());
        }
        return (result != NULL);
    }

    template<typename type>
    static type NUM(const cJSON* parent,
        const char* route, type default_value = 0) {
        cJSON* node = CJSON3::Route(parent, route);
        if (cJSON_IsNumber(node)) {
            if (typeid(default_value) == typeid(float) ||
                typeid(default_value) == typeid(double)) {
                return (type)node->valuedouble;
            } else {
                return (type)node->valueint;
            }
        } else {
            return default_value;
        }
    }

    static std::string STR(const cJSON* parent,
        const char* route, std::string default_value = "") {
        cJSON* node = CJSON3::Route(parent, route);
        if (cJSON_IsString(node)) {
            return node->valuestring ? node->valuestring : default_value;
        } else {
            return default_value;
        }
    }

    static bool StrEqual(cJSON* node, const char* str) {
        if (cJSON_IsString(node) && str) {
            if (!strcasecmp(node->valuestring, str)) {
                return true;
            }
        } return false;
    }

    // 遍历平级节点
    static void Ergodic(const cJSON* parent, void(*cbs)(const cJSON*)) {
        cJSON* element = parent->child;
        while (element) {
            if (element->string) {
                if (cbs) {
                    cbs(element);
                }
            } element = element->next;
        }
    }

    // 给对象添加数字
    template <typename type>
    bool ADD(cJSON* parent, const std::string& name, type dat) {
        if (cJSON_IsArray(parent) || cJSON_IsObject(parent)) {
            cJSON_AddNumberToObject(parent, name.c_str(), dat);
            return true;
        } else {
            return false;
        }
    }

    static bool Delete(cJSON* parent, const std::string& item_name) {
        if (cJSON_IsObject(parent)) {
            cJSON_DeleteItemFromObject(parent, item_name.c_str());
            return true;
        } else {
            return false;
        }
    }

    static bool Replace(cJSON* parent,
        const std::string& item_name, cJSON* new_item) {
        if (cJSON_IsObject(parent) &&
            cJSON_IsObject(new_item) && !item_name.empty()) {
            cJSON_ReplaceItemInObject(parent, item_name.c_str(), new_item);
            return true;
        } else {
            return false;
        }
    }

    static std::string PrintFormatted(const cJSON* item,
        const char* default_value = "") {
        std::string result = default_value;
        if (cJSON_Valid(item)) {
            char* str = cJSON_Print(item);
            if (str != NULL) {
                result = str;
                cJSON_free(str);
            }
        }
        return result;
    }

    static std::string PrintUnformatted(const cJSON* item,
        const char* default_value = "") {
        std::string result = default_value;
        if (cJSON_Valid(item)) {
            char* str = cJSON_PrintUnformatted(item);
            if (str != NULL) {
                result = str;
                cJSON_free(str);
            }
        }
        return result;
    }
};


///////////////////////////////////////////////////////
// 只接受根节点（子节点随着根节点一起被释放）
class CJSCHK
{
    cJSON* pROOT;
public:
    CJSCHK(cJSON* root) {
        pROOT = root;
    };

    virtual ~CJSCHK() {
        if (pROOT) {
            cJSON_Delete(pROOT);
            pROOT = NULL;
        }
    }

    bool Valid() {
        if (pROOT) {
            return cJSON_Valid(pROOT);
        } else {
            return false;
        }
    }
};


///////////////////////////////////////////////////////
#endif  //!JSON3_HPP_INCLUDE
