#ifndef SM4_HPP_INCLUDE
#define SM4_HPP_INCLUDE

#include <string>
////////////////////////////////////////////////////
enum ESM4 : unsigned char { ESM4_ECB, ESM4_CBC };
class CSM4
{
public:
    explicit CSM4(unsigned char type = ESM4_ECB) {
        memset(this->ivs, 0, sizeof(this->ivs));
        memset(this->key, 0, sizeof(this->key));
        this->type = type;
    };

    std::string encrypt(const std::string& data);
    std::string decrypt(const std::string& data);
    void SetType(unsigned char type = ESM4_ECB) {
        this->type = type;
    };

    bool SetIV(const std::string& iv) {
        bool result = false;
        if (iv.size() == 16) {
            memcpy(this->ivs, iv.c_str(), 16);
            result = true;
        } return result;
    }

    bool SetKey(const std::string& key) {
        bool result = false;
        if (key.size() == 16) {
            memcpy(this->key, key.c_str(), 16);
            result = true;
        } return result;
    }

private:

    unsigned char type;
    unsigned char ivs[16];
    unsigned char key[16];
};

////////////////////////////////////////////////////
#endif // !SM4_HPP_INCLUDE
