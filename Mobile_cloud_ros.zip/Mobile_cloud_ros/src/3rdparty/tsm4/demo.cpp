#include <iostream>
#include <string.h>
#include "tsm4.hpp"
#include "tsm4.h"

void test_c(const char* dat) {
    if (dat != NULL) {
        int data_sz = strlen(dat);
        unsigned char key[16], ivs[16];
        memcpy(key, "1234567890123456", 16);
        memcpy(ivs, "asdfghjklzxcvbnm", 16);

        sm4_context t0;
        sm4_set_enckey(&t0, key);
        unsigned char out10[data_sz];
        unsigned char out20[data_sz];
        memset(out10, 0, sizeof(out10));
        memset(out20, 0, sizeof(out20));
        sm4_crypt_ecb(&t0, (unsigned char*)dat, data_sz, out10);
        sm4_crypt_cbc(&t0, ivs, (unsigned char*)dat, data_sz, out20);

        sm4_set_deckey(&t0, key);
        unsigned char out11[data_sz];
        unsigned char out21[data_sz];
        memset(out11, 0, sizeof(out11));
        memset(out21, 0, sizeof(out21));
        sm4_crypt_ecb(&t0, out10, data_sz, out11);
        sm4_crypt_cbc(&t0, ivs, out20, data_sz, out21);
    }
}

void test_p(const std::string& dat) {
    if (!dat.empty()) {
        CSM4 s0(ESM4::ESM4_ECB);
        s0.SetIV("asdfghjklzxcvbnm");
        s0.SetKey("1234567890123456");
        std::cout << s0.encrypt(dat) << std::endl;
        std::cout << s0.decrypt(s0.encrypt(dat)) << std::endl;

        CSM4 s1(ESM4::ESM4_ECB);
        s1.SetKey("1234567890123456");
        std::cout << s1.encrypt(dat) << std::endl;
        std::cout << s1.decrypt(s1.encrypt(dat)) << std::endl;
    }
}

int main() {
    test_c("hello sm4!");
    test_p("hello sm4!");

    getchar();
    return 0;
}
