#include "xml_wrap.hpp"


/////////////////////////////////////////////////////////////////////////
CXmlWrap::CXmlWrap() : m_bChanged(false), m_bAutoSave(false) {
	m_filePath.clear();
}


CXmlWrap::CXmlWrap(const std::string& filePath, bool auto_save)
	: m_bChanged(false) {
	Open(filePath, auto_save);
	m_filePath = filePath;
}


CXmlWrap::~CXmlWrap() {
	if (m_bAutoSave &&
		m_bChanged) {
		Save();
	} m_doc.Clear();
}


bool CXmlWrap::Open(const std::string& fileName, bool auto_save) {
	if (fileName.empty()) {
		printf("CXmlWrap::Open - Invalid xml path: %s.\n", fileName.c_str());
		return false;
	}

	XMLError rv = m_doc.LoadFile(fileName.c_str());
	if (rv != XML_SUCCESS) {
		printf("CXmlWrap::Open - m_doc.LoadFile(%s) failed: %s.\n",
			fileName.c_str(), GetErrorDesc(rv));
		return false;
	}

	return true;
}


bool CXmlWrap::Save(const std::string& filePath) {
	std::string sPathName = filePath;
	if (sPathName.empty()) {
		sPathName = m_filePath;
	}

	XMLError rv = m_doc.SaveFile(sPathName.c_str(), false);
	if (rv != XML_SUCCESS) {
		printf("CXmlWrap::Save - m_doc.SaveFile(%s) Failed: %s.\n",
			sPathName.c_str(), GetErrorDesc(rv));
		return false;
	}

	m_bChanged = false;
	printf("CXmlWrap::Save - OK (Path: %s).\n", sPathName.c_str());
	return true;
}


XMLElement* CXmlWrap::GetRoot() {
	return m_doc.RootElement();
}


XMLElement* CXmlWrap::Route(const std::string& path) {
	// 以根节点的下一级作为路径起始点(根不能包含到路径中，最后一级只取第一个节点)
	XMLElement* root = m_doc.RootElement();
	XMLElement* child = NULL;
	if (root && !path.empty()) {
		std::string temp = path.c_str();
		child = root->FirstChildElement();
		char* token = strtok((char*)temp.c_str(), "/");
		while (token && child) {
			if (strcasecmp(token, child->Name()) != 0) {
				child = child->NextSiblingElement();
			} else {
				token = strtok(NULL, "/");
				if (token) {
					// 如果最后一级有多个子节点(数组)，只取第一个节点，后面自己再遍历
					child = child->FirstChildElement();
				} else {
					break;
				}
			}
		}
	}

	return child;
}


XMLElement* CXmlWrap::Route(const XMLElement* parent, const std::string& path) {
	// 以根节点的下一级作为路径起始点(根不能包含到路径中，如果最后一级有多个节点，只取第一个)
	XMLElement* child = NULL;
	if (parent && !path.empty()) {
		std::string temp = path.c_str();
		// 以根节点的下一级作为路径起始点(根不能包含到路径中)
		char* token = strtok((char*)temp.c_str(), "/");
		child = (XMLElement*)parent->FirstChildElement();
		while (token && child) {
			if (strcasecmp(token, child->Name()) != 0) {
				child = child->NextSiblingElement();
			} else {
				token = strtok(NULL, "/");
				if (token) {
					// 如果最后一级有多个子节点(数组)，只取第一个节点，后面自己再遍历
					child = child->FirstChildElement();
				} else {
					break;
				}
			}
		}
	}

	return child;
}


const char* CXmlWrap::GetErrorDesc(XMLError rv) {
	if (rv >= XML_SUCCESS && rv < XML_ERROR_COUNT) {
		switch (rv) {
			case XML_NO_ATTRIBUTE:
				return "没有此属性";
				break;

			case XML_WRONG_ATTRIBUTE_TYPE:
				return "错误的属性类型";
				break;

			case XML_ERROR_FILE_NOT_FOUND:
				return "打开文件时,XML文件没有找到";
				break;

			case XML_ERROR_FILE_COULD_NOT_BE_OPENED:
				return "XML文件没有打开";
				break;

			case XML_ERROR_FILE_READ_ERROR:
				return "读取XML文件时错误";
				break;

			case XML_ERROR_PARSING_ELEMENT:
				return "解析XML元素错误";
				break;

			case XML_ERROR_PARSING_ATTRIBUTE:
				return "解析XML属性错误";
				break;

			case XML_ERROR_PARSING_TEXT:
				return "解析XML文本错误";
				break;

			case XML_ERROR_PARSING_CDATA:
				return "XML_ERROR_PARSING_CDATA";
				break;

			case XML_ERROR_PARSING_COMMENT:
				return "XML_ERROR_PARSING_COMMENT";
				break;

			case XML_ERROR_PARSING_DECLARATION:
				return "XML_ERROR_PARSING_DECLARATION";
				break;

			case XML_ERROR_PARSING_UNKNOWN:
				return "XML_ERROR_PARSING_UNKNOWN";
				break;

			case XML_ERROR_EMPTY_DOCUMENT:
				return "XML_ERROR_EMPTY_DOCUMENT";
				break;

			case XML_ERROR_MISMATCHED_ELEMENT:
				return "XML_ERROR_MISMATCHED_ELEMENT";
				break;

			case XML_ERROR_PARSING:
				return "XML_ERROR_PARSING";
				break;

			default: break;
		}
	}

	return "UNKOWN";
}
