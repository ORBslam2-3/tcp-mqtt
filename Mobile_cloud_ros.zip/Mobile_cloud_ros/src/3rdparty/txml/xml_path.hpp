#ifndef XML_PATH_HPP
#define XML_PATH_HPP

#include <string>
#if defined(_WIN32)
# include <windows.h>
# define SEPARATOR_C '\\'
# define SEPARATOR_S "\\"
#else
# include <unistd.h>
# define SEPARATOR_C '/'
# define SEPARATOR_S "/"
#endif

/////////////////////////////////////////////////////////////////////////
class CPathHelp
{
public:
    CPathHelp() {};
    virtual ~CPathHelp() {};
    static std::string CurrentDir();
    static bool CreateDir(const std::string& path);
    static bool IsFile(const std::string& filePath);
    static bool FileExists(const std::string& path);
    static bool DeleteFile(const std::string& path);
    static bool IsDirectory(const std::string& path);
    static bool CreateMultDirs(const std::string& path);
    static std::size_t FileSize(const std::string& path);
    static std::string MakeAbsolute(const std::string& file);
};


/////////////////////////////////////////////////////////////////////////
class CXmlPath
{
    std::string m_filePath;
public:
    CXmlPath(bool init_with_current_dir = true);
    virtual ~CXmlPath();

    // 设置: 全局根目录(替换其它根目录)
    void SetROOT(const std::string& filePath);

    // 添加: 绝对子路径
    void Add_Absolute_Dir(const std::string& dir);
    void Add_Absolute_File(const std::string& file);

    // 添加: 相对子路径
    void Add_Relative_Dir(const std::string& dir);
    void Add_Relative_File(const std::string& file);

    // 获取路径结果, 参数不能为相对路径文件
    std::string GetPathName(const std::string& filename = "");

    // 获取当前路径下的文件或者子目录路径
    static std::string GetPathName2(const std::string& name = "");
};


/////////////////////////////////////////////////////////////////////////
#endif  //!XML_PATH_HPP
