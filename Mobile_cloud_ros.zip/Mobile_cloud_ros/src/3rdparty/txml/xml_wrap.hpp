#ifndef XML_WRAP_HPP
#define XML_WRAP_HPP

#include <string>
#include <sstream>
#include "tinyxml2.h"
using namespace tinyxml2;
/////////////////////////////////////////////////////////////////////////
class CXmlWrap
{
    XMLDocument m_doc;
    std::string m_filePath;    // 文件路径 
    volatile bool m_bChanged;  // 数据是否更改
    volatile bool m_bAutoSave; // 是否自动保存
public:
    CXmlWrap();
    CXmlWrap(const std::string& filePath, bool auto_save = false);
    const char* PathName() { return m_filePath.c_str(); }
    const char* GetErrorDesc(XMLError rv);
    virtual ~CXmlWrap();

    bool Open(const std::string& fileName, bool auto_save = false);
    bool IsOpened() { return (m_doc.RootElement() != NULL); }
    bool Save(const std::string& filePath = "");
    static const char* STR(const char* dat) {
        if (dat) {
            return dat;
        } else {
            return "";
        }
    }

    XMLElement* GetRoot();
    XMLElement* Route(const std::string& path);
    XMLElement* Route(const XMLElement* item, const std::string& path);

    template<typename type>
    bool SetValue(const std::string& path, type value) {
        XMLElement* item = Route(path);
        if (item != NULL) {
            std::stringstream sSs;
            sSs << value;
            item->SetText(sSs.str().c_str());
            m_bChanged = true;
            return true;
        } else {
            return false;
        }
    }

    template<typename type>
    type GetValue(const std::string& path, type default_dat) {
        type result = default_dat;
        XMLElement* item = Route(path);
        if (item != NULL) {
            const char* text = item->GetText();
            if (text) {
                std::stringstream sSs;
                sSs << text;
                sSs >> result;
            }
        } return result;
    }

    template<typename type>
    bool SetValue(XMLElement* item, type dat) {
        if (item != NULL) {
            std::stringstream sSs;
            sSs << dat;
            item->SetText(sSs.str().c_str());
            m_bChanged = true;
            return true;
        } else {
            return false;
        }
    }

    template<typename type>
    type GetValue(XMLElement* item, type default_dat) {
        type result = default_dat;
        if (item != NULL) {
            const char* text = item->GetText();
            if (text) {
                std::stringstream sSs;
                sSs << text;
                sSs >> result;
            }
        } return result;
    }

    template<typename type>
    bool SetValue(XMLElement* item, const std::string& path, type dat) {
        XMLElement* node = Route(item, path);
        if (node != NULL) {
            std::stringstream sSs; sSs << dat;
            node->SetText(sSs.str().c_str());
            m_bChanged = true;
            return true;
        } else {
            return false;
        }
    }

    template<typename type>
    type GetValue(XMLElement* item, const std::string& path, type default_dat) {
        type result = default_dat;
        XMLElement* node = Route(item, path);
        if (node) {
            const char* text = node->GetText();
            if (text) {
                std::stringstream sSs;
                sSs << text;
                sSs >> result;
            }
        } return result;
    }

    template<typename type>
    bool SetAttribute(const std::string& path, const char* name, type value) {
        XMLElement* root = m_doc.RootElement();
        XMLElement* item = Route(root, path);
        if (item && name) {
            std::stringstream sSs;
            sSs << value;
            item->SetAttribute(name, sSs.str().c_str());
            m_bChanged = true;
            return true;
        } return false;
    }

    template<typename type>
    type GetAttribute(const std::string& path, const char* name, type default_dat) {
        type result = default_dat;
        XMLElement* root = m_doc.RootElement();
        XMLElement* item = Route(root, path);
        if (item && name) {
            const XMLAttribute* attr = item->FindAttribute(name);
            if (attr && attr->Value()) {
                std::stringstream sSs;
                sSs << attr->Value();
                sSs >> result;
            }
        } return result;
    }

    template<typename type>
    bool SetAttribute(XMLElement* item, const char* name, type value) {
        if (item && name) {
            std::stringstream sSs;
            sSs << value;
            item->SetAttribute(name, sSs.str().c_str());
            m_bChanged = true;
            return true;
        } return false;
    }

    template<typename type>
    type GetAttribute(const XMLElement* item, const char* name, type default_dat) {
        type result = default_dat;
        const XMLAttribute* attr = item->FindAttribute(name);
        if (attr && attr->Value()) {
            std::stringstream sSs;
            sSs << attr->Value();
            sSs >> result;
        }  return result;
    }

    template<typename type>
    bool SetAttribute(XMLElement* item, const std::string& path, const char* name, type value) {
        XMLElement* node = Route(item, path);
        if (node && name) {
            std::stringstream sSs;
            sSs << value;
            node->SetAttribute(name, sSs.str().c_str());
            m_bChanged = true;
            return true;
        } return false;
    }

    template<typename type>
    type GetAttribute(const XMLElement* item, const std::string& path, const char* name, type default_dat) {
        type result = default_dat;
        XMLElement* node = Route(item, path);
        if (node && name) {
            const XMLAttribute* attr = node->FindAttribute(name);
            if (attr && attr->Value()) {
                std::stringstream sSs;
                sSs << attr->Value();
                sSs >> result;
            }
        } return result;
    }
};

/////////////////////////////////////////////////////////////////////////
#endif //!XML_WRAP_HPP
