#include <string.h>
#include <sys/stat.h>
#include "xml_path.hpp"


/////////////////////////////////////////////////////////////////////////
std::string CPathHelp::CurrentDir() {
    char dir[260] = {'\0'};
#if defined(_WIN32)
    DWORD idx = ::GetModuleFileNameA(NULL, dir, 260);
    while (idx-- > 0) {
        if (dir[idx] != '\\') {
            dir[idx] = '\0';
        } else {
            dir[++idx] = '\0';
            break;
        }
    }
#else
    if (::getcwd(dir, 260)) {
        int last = strlen(dir);
        if (dir[last] != '/') {
            dir[last] = '/';
        }
    } else {
        dir[0] = '\0';
    }
#endif
    return dir;
}


bool CPathHelp::FileExists(const std::string& path) {
#if defined(_WIN32)
    DWORD attrib = GetFileAttributesA(path.c_str());
    return (attrib != INVALID_FILE_ATTRIBUTES);
#else
    struct stat sb;
    return stat(path.c_str(), &sb) == 0;
#endif
}


bool CPathHelp::DeleteFile(const std::string& path) {
#if !defined(_WIN32)
    return std::remove(path.c_str()) == 0;
#else
    return DeleteFileA(path.c_str()) != 0;
#endif
}


bool CPathHelp::IsFile(const std::string& path) {
#if defined(_WIN32)
    DWORD attr = GetFileAttributesA(path.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES) {
        if (!(attr & FILE_ATTRIBUTE_DIRECTORY)) {
            return true;
        }
    }
#else
    struct stat sb;
    if (!stat(path.c_str(), &sb)) {
        return S_ISREG(sb.st_mode);
    }
#endif
    return false;
}


bool CPathHelp::IsDirectory(const std::string& path) {
#if defined(_WIN32)
    DWORD attr = GetFileAttributesA(path.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES) {
        if ((attr & FILE_ATTRIBUTE_DIRECTORY)) {
            return true;
        }
    }
#else
    struct stat sb;
    if (!stat(path.c_str(), &sb)) {
        return S_ISDIR(sb.st_mode);
    }
#endif
    return false;
}


bool CPathHelp::CreateDir(const std::string& path) {
#if defined(_WIN32)
    if (CreateDirectoryA(path.c_str(), NULL))
        return true;
#else
    if (!mkdir(path.c_str(), S_IRWXU))
        return true;
#endif
    return false;
}


bool CPathHelp::CreateMultDirs(const std::string& path) {
    bool result = true; int a = 0;
    std::string temp = path.c_str();
    char* token = strtok((char*)temp.c_str(), SEPARATOR_S);
    while (token != NULL) {
        if (CreateDir(token)) {
            token = strtok(NULL, SEPARATOR_S);
        } else if (a++ > 3) {
            result = false;
            break;
        }
    }

    return result;
}


std::size_t CPathHelp::FileSize(const std::string& path) {
    std::size_t fileSize = 0;
#if defined(_WIN32)
    struct _stati64 sb;
    if (!_stati64(path.c_str(), &sb)) {
        fileSize = (size_t)sb.st_size;
    }
#else
    struct stat sb;
    if (!stat(path.c_str(), &sb)) {
        fileSize = (size_t)sb.st_size;
    }
#endif
    return fileSize;
}


std::string CPathHelp::MakeAbsolute(const std::string& file) {
    char temp[260] = {'\0'};
#if !defined(_WIN32)
    if (!realpath(file.c_str(), temp)) {
        temp[0] = '\0';
    }
#else
    if (!::GetFullPathNameA(file.c_str(), file.size(), temp, NULL)) {
        temp[0] = '\0';
    }
#endif
    return temp;
}


/////////////////////////////////////////////////////////////////////////
CXmlPath::CXmlPath(bool init_with_current_dir) {
    if (init_with_current_dir) {
        m_filePath = CPathHelp::CurrentDir();
    } else {
        m_filePath.clear();
    }
}


CXmlPath::~CXmlPath() {
    m_filePath.clear();
}


void CXmlPath::SetROOT(const std::string& filePath) {
    m_filePath = filePath;
}


void CXmlPath::Add_Absolute_Dir(const std::string& dir) {
    if (!dir.empty()) {
        m_filePath += dir;
        if (dir.back() != '/') {
            m_filePath.append(1, '/');
        }
    }
}


void CXmlPath::Add_Absolute_File(const std::string& file) {
    if (!file.empty()) {
        m_filePath += file;
    }
}


void CXmlPath::Add_Relative_Dir(const std::string& dir) {
    if (!dir.empty()) {
        m_filePath += dir; {
            char temp[260] = {'\0'};
            realpath(m_filePath.c_str(), temp);
            m_filePath = temp;
            if (m_filePath.back() != '/') {
                m_filePath.append(1, '/');
            }
        }
    }
}


void CXmlPath::Add_Relative_File(const std::string& file) {
    if (!file.empty()) {
        m_filePath += file;
        char temp[260] = {'\0'};
        realpath(m_filePath.c_str(), temp);
        m_filePath = temp;
    }
}


std::string CXmlPath::GetPathName(const std::string& filename) {
    if (!filename.empty()) {
        m_filePath += filename;
    } return m_filePath;
}


std::string CXmlPath::GetPathName2(const std::string& name) {
    std::string sPathName = CPathHelp::CurrentDir();
    if (!name.empty()) {
        sPathName += name;
    } return sPathName;
}

