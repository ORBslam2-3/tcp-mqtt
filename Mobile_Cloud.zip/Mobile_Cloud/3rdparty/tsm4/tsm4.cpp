#include <string.h>
#include "tsm4.hpp"
#include "tsm4.h"


////////////////////////////////////////////////////////////////////////////////////////////////////
std::string CSM4::encrypt(const std::string& data) {
    std::string result;
    if (!data.empty()) {
        // PKCS7Padding
        int length = (data.size() / 16 + 1) * 16;
        unsigned char input[length], output[length];
        memset(input, length - data.size(), length);
        memcpy(input, data.data(), data.size());
        memset(output, 0, length);

        sm4_context ctx;
        sm4_set_enckey(&ctx, this->key);
        if (this->type == ESM4::ESM4_ECB) {
            sm4_crypt_ecb(&ctx, input, length, output);
        } else if (this->type == ESM4::ESM4_CBC) {
            sm4_crypt_cbc(&ctx, this->ivs, input, length, output);
        }

        //　对于不可见字符, 某些应用场合可能会有问题了
        result.assign((const char*)output, length);
    }

    return result;
}


std::string CSM4::decrypt(const std::string& data) {
    std::string result;
    if (data.size() >= 16) {
        int length = data.size();
        unsigned char input[length];
        unsigned char output[length];
        memcpy(input, data.data(), length);
        memset(output, 0, length);

        sm4_context ctx;
        sm4_set_deckey(&ctx, this->key);
        if (this->type == ESM4::ESM4_ECB) {
            sm4_crypt_ecb(&ctx, input, length, output);
        } else if (this->type == ESM4::ESM4_CBC) {
            sm4_crypt_cbc(&ctx, this->ivs, input, length, output);
        }

        //　对于不可见字符, 某些应用场合可能会有问题了
        length = length - (int)output[length - 1];
        if (length > 0) {
            result.assign((const char*)output, length);
        }
    }

    return result;
}
