#ifndef SM4_H_INCLUDE
#define SM4_H_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct
    {
        // 加载模式(1:加密;0:解密)
        unsigned char enc_mode;
        // 内部生成并使用,无需外部处理
        unsigned long sk[32];
    } sm4_context;

    //  SM4 key schedule (128-bit, encryption)
    void sm4_set_enckey(sm4_context* ctx, unsigned char key[16]);

    // SM4 key schedule (128-bit, decryption)
    void sm4_set_deckey(sm4_context* ctx, unsigned char key[16]);

    // SM4-ECB block encryption/decryption
    void sm4_crypt_ecb(sm4_context* ctx, unsigned char* dat, int len, unsigned char* out);

    // SM4-CBC buffer encryption/decryption
    void sm4_crypt_cbc(sm4_context* ctx, unsigned char iv[16], unsigned char* dat, int len, unsigned char* out);

#ifdef __cplusplus
}
#endif
#endif // !SM4_H_INCLUDE
