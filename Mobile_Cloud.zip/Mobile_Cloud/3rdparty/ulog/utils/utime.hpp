#ifndef UTIME_HPP_INCLUDE
#define UTIME_HPP_INCLUDE


#include <time.h>
#include <unistd.h>
#include <typeinfo>
////////////////////////////////////////////////////////////
class CTime2
{
public:
    static time_t time_ms() {
        // 从系统启动的时刻开始计时(毫秒)
        // 开机连续跑49.7天后从0开始计时
        struct timespec ts = {0, 0};
        clock_gettime(CLOCK_MONOTONIC, &ts);
        // 返回类型: ILP64位系统下计数到一半重新循环
        time_t rv = ts.tv_sec * 1000;
        rv += ts.tv_nsec * 1E-6;
        return rv;
    }

    static void sleep_ms(time_t ms) {
        usleep(ms * 1000);
    }

    static void sleep_second(time_t sec) {
        usleep(sec * 1000000);
    }

    static double time_second() {
        struct timespec ts = {0, 0};
        clock_gettime(CLOCK_MONOTONIC, &ts);
        double second = ts.tv_sec;
        second += ts.tv_nsec * (double)1E-9;
        return second;
    }

    static time_t time_len(time_t& tick) {
        time_t now = CTime2::time_ms();
        time_t ret = 0;
        if (now > tick) {
            ret = now - tick;
        } tick = CTime2::time_ms();
        return ret;
    }

    static void sleep_ms(time_t& tick, time_t timeout_ms) {
        time_t now = CTime2::time_ms();
        if (tick > now) {
            // 时间环循环了跳过SLEEP
            tick = CTime2::time_ms();
        } else if (now >= tick) {
            time_t t = now - tick;
            if (t < timeout_ms) {
                t = timeout_ms - t;
                usleep(t * 1000);
            } tick = CTime2::time_ms();
        }
    }

    static bool timeout_ms(time_t& tick, time_t timeout_ms) {
        time_t now = CTime2::time_ms();
        if (tick > now) {
            // 时间环循环了，直接触发一次，此处不精确
            tick = now;
            return true;
        } else if (now > tick) {
            time_t t = now - tick;
            if (t >= timeout_ms) {
                tick = now;
                return true;
            }
        } return false;
    }

    static bool timeout_sec(double& tick, double timeout_sec) {
        double now = CTime2::time_second();
        if (tick > now) {
            // 时间环循环了，直接触发一次，此处不精确
            tick = now;
            return true;
        } else if (now > tick) {
            double t = now - tick;
            if (t >= timeout_sec) {
                tick = now;
                return true;
            }
        } return false;
    }

    static void timeval(struct timeval* tv, int timeout_ms) {
        if (tv != NULL) {
            // 秒钟： 毫秒转秒需要除以 1000
            tv->tv_sec = (timeout_ms / 1000);
            // 微秒: 毫秒转微秒需要乘 1000
            tv->tv_usec = 1000 * (timeout_ms % 1000);
        };
    }

    template<typename type>
    static type RandT(type range_min, type range_max) {
        if (range_min > range_max) {
            type temp = range_max;
            range_max = range_min;
            range_min = temp;
        }
        double r = rand() / (double)RAND_MAX;
        return r * (range_max - range_min) + range_min;
    }
};


////////////////////////////////////////////////////////////
// 适合精度不高的场合(部分函数内部更新了时间，外部计算消耗没有计算在内)
// 支持的数据类型为: time_t 和 double
template<typename type>
class CTime3
{
public:
    // type 为 time_t 时返回 毫秒
    // type 为 double 时返回 秒(带小数)
    static type current_time() {
        type result = 0;
        struct timespec ts = {0, 0};
        clock_gettime(CLOCK_MONOTONIC, &ts);
        if (typeid(type) == typeid(double)) {
            // 秒作为整数其它作为小数
            result = ts.tv_sec;
            // 秒钟: 纳秒转微秒需要除 10^9
            result += ts.tv_nsec * (double)1E-9;
        } else {
            // 毫秒: 秒转毫秒需要乘以 1000
            result *= 1000; // 转成毫秒
            // 微秒: 纳秒转微秒需要除 10^6
            result += ts.tv_nsec * (double)1E-6;
        } return result;
    }

    static type time_len(const type& tick) {
        // 返回两个时间的间隔，适合精度不高的场合(函数内更新了时间)
        type now = CTime3<type>::current_time();
        if (tick > now) {
            // 时间环循环了，此处不精确
            return 0;
        } else if (now > tick) {
            return (now - tick);
        } return 0;
    }

    static bool timeout(type& tick, type timeout_ms) {
        type now = CTime3<type>::current_time();
        if (tick > now) {
            // 时间环循环了，直接触发一次，此处不精确
            tick = now;
            return true;
        } else if (now > tick) {
            type t = now - tick;
            if (t >= timeout_ms) {
                tick = now;
                return true;
            }
        } return false;
    }

    static type time_last(type& tick, type timeout) {
        // 返回两个时间的间隔，适合精度不高的场合(函数内更新了时间)
        type now = CTime3<type>::current_time();
        if (tick > now) {
            // 时间环循环了，取超时1/3，此处不精确
            tick = CTime3<type>::current_time();
            return timeout / 3;
        } else if (now >= tick) {
            type d = (now - tick), t = 0;
            if (d < timeout) {
                t = timeout - d;
            } tick = CTime3<type>::current_time();
            return t;
        }
    }
};


////////////////////////////////////////////////////////
// 用于多组数字计数，达到指定的计数返回true, 并从头开始计数
template<typename type, int MAX_NUM = 10>
class CCounter
{
    type m[MAX_NUM];
public:
    CCounter() {
        int idx = 0;
        while (idx < MAX_NUM) {
            this->m[idx++] = (type)0;
        }
    }

    bool Update(int idx, type times = 0) {
        if (idx >= 0 && idx < MAX_NUM) {
            this->m[idx] = times;
            return true;
        } else {
            return false;
        }
    }

    bool Reach(int idx, type times) {
        if (idx >= 0 && idx < MAX_NUM) {
            if (this->m[idx]++ >= times) {
                this->m[idx] = 0;
                return true;
            }
        } return false;
    }
};


////////////////////////////////////////////////////////
// 用于多组毫秒计时，达到指定的时长返回true, 并从头开始计时
template<int MAX_NUM = 10>
class CTimeOut
{
    time_t m[MAX_NUM];
public:
    CTimeOut() {
        int idx = 0;
        while (idx < MAX_NUM) {
            this->m[idx++] = 0;
        }
    }

    bool TimeLen(int idx, const time_t& tick) {
        // 返回两个时间的间隔(时间长度)
        if (idx >= 0 && idx < MAX_NUM) {
            time_t now = CTime2::time_ms();
            if (tick > this->m[idx]) {
                // 时间环循环了，此处不精确
                return 0;
            } else if (now >= this->m[idx]) {
                int t = (int)(now - tick);
                return t;
            }
        } return 0;
    }

    bool Update(int idx, time_t timeout_ms = -1) {
        if (idx >= 0 && idx < MAX_NUM) {
            if (timeout_ms == (time_t)-1) {
                this->m[idx] = CTime2::time_ms();
            } else {
                this->m[idx] = timeout_ms;
            } return true;
        } else {
            return false;
        }
    }

    bool TimeOut(int idx, time_t timeout_ms) {
        if (idx >= 0 && idx < MAX_NUM) {
            time_t now = CTime2::time_ms();
            if (this->m[idx] > now) {
                // 时间环循环了直接触发一次，此处不精确
                this->m[idx] = CTime2::time_ms();
                return true;
            } else if (now > this->m[idx]) {
                time_t t = now - this->m[idx];
                if (t >= timeout_ms) {
                    this->m[idx] = CTime2::time_ms();
                    return true;
                }
            }
        } return false;
    }
};


////////////////////////////////////////////////////////
#endif //!UTIME_HPP_INCLUDE
