#ifndef UDEBUG_H_INCLUDE
#define UDEBUG_H_INCLUDE

#include <string>
#include <string.h>
#include <unistd.h>
#ifndef DBG_BIT_DAT
#define DBG_BIT_DAT(n) (1<<(n))
#endif //!DBG_BIT_DAT
////////////////////////////////////////////////////////////
class CDebug2
{
public:
    CDebug2(bool use_app_dir = true) {
        this->FetchDir(use_app_dir);
    }

    CDebug2(const char* fileName, bool use_app_dir = true) {
        this->FetchDir(use_app_dir);
        if (fileName != NULL) {
            this->fileName = fileName;
        }
    }

    bool FlagInclude(const char* key, int flag) {
        int data = FlagRead(this->fileName.c_str(), key);
        if (data & flag) {
            return true;
        } else {
            return false;
        }
    }

    int FlagRead(const char* key) {
        return FlagRead(this->fileName.c_str(), key);
    }

    int FlagRead(const char* fileName, const char* key) {
        int result = -1;
        // 读取用户配置的标记数据
        if (fileName && key && strlen(key) > 0) {
            std::string filePath = this->PathDir + fileName;
            if (!filePath.empty()) {
                FILE* fp = fopen(filePath.c_str(), "r");
                if (fp) {
                    char line[128] = {0};
                    int len = (int)strlen(key);
                    while (fgets(line, 128, fp)) {
                        char* ptr = strcasestr(line, key);
                        if (ptr) {
                            result = atoi(ptr + len);
                            break;
                        }
                    } fclose(fp);
                }
            }
        }

        return result;
    }

private:

    std::string PathDir, fileName;
    inline void FetchDir(bool use_app_dir) {
        this->fileName.clear();
        if (!use_app_dir) {
            this->PathDir = "/usr/var/";
        } else {
            this->PathDir.clear();
            char dir[260] = {'\0'};
            if (::getcwd(dir, 260)) {
                int last = strlen(dir);
                if (dir[last] != '/') {
                    dir[last] = '/';
                } this->PathDir = dir;
            }
        }
    }
};

////////////////////////////////////////////////////////////
#endif  //!UDEBUG_H_INCLUDE
