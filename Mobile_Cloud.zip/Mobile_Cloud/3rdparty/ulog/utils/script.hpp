#ifndef SCRIPT_HPP_INCLUDE
#define SCRIPT_HPP_INCLUDE

#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "../ulog.h"

#ifndef SCRIPT_SUCCEED
#define SCRIPT_SUCCEED(r) ((r) == 0)
#endif  //!SCRIPT_SUCCEED
/////////////////////////////////////////////////////////////////
class CScript
{
public:
    CScript() {};
    virtual ~CScript() {};
    int RunShell(const char* path) {
        const char* cmd = this->ReadCmd(path);
        if (!cmd) {
            LOG_ERROR("CScript - ReadCmd(%s) failed(errno: %d)", path, errno);
            return -10;
        } else {
            int rv = RunCmmd(cmd);
            free((void*)cmd);
            return rv;
        }
    }

    int RunCmmd(const char* cmd) {
        FILE* fp = popen(cmd, "r");
        if (!fp) {
            LOG_ERROR("CScript::RunCmmd - popen('r') failed(errno: %d), cmd: %s\n", errno, cmd);
            return -11;
        }

        char temp[1024] = {0};
        // 在shell中有输出 会导致脚本没有执行完 提前退出，
        // 可以考虑两种解决方案:
        // (1) 在shell脚本里不要输出；
        // (2) 在pclose()前调用fgets()读取所有输出。
        while (fgets(temp, sizeof(temp), fp)) {
            if ('\n' == temp[strlen(temp) - 1]) {
                temp[strlen(temp) - 1] = '\0';
            } LOG_DEBUG("\r\nCScript::RunCmmd - 命令输出\r\n%s\r\n", temp);
        }

        // pclose() 会阻塞等待子进程结束
        int rc = pclose(fp);
        if (-1 == rc) {
            LOG_ERROR("CScript::RunCmmd - pclose(fp) failed(errno: %d)", errno);
            return -12;
        }

        // 在ARM板上子跑的时候，会出现僵尸进程
        LOG_DEBUG("CScript::RunCmmd - 子进程结束状态[%d]，命令返回值[%d]", rc, WEXITSTATUS(rc));
        return 0;
    }

    int RunCmd256(const char* format, ...) {
        va_list v;
        va_start(v, format);
        char temp[256] = {0};
        vsnprintf(temp, sizeof(temp), format, v);
        va_end(v);

        LOG_DEBUG("CScript::RunCmd256 - 命令:\r\n%s\r\n", temp);
        FILE* fp = popen(temp, "r");
        if (!fp) {
            LOG_ERROR("CScript::RunCmd256 - popen('r') failed(errno: %d), cmd: %s\n", errno, temp);
            return -11;
        }

        // 在shell中有输出 会导致脚本没有执行完 提前退出，
        // 可以考虑两种解决方案:
        // (1) 在shell脚本里不要输出；
        // (2) 在pclose()前调用fgets()读取所有输出。
        while (fgets(temp, sizeof(temp), fp)) {
            if ('\n' == temp[strlen(temp) - 1]) {
                temp[strlen(temp) - 1] = '\0';
            } LOG_DEBUG("\r\nCScript::RunCmd256 - 命令输出\r\n%s\r\n", temp);
        }

        // pclose() 会阻塞等待子进程结束
        int rc = pclose(fp);
        if (-1 == rc) {
            LOG_ERROR("CScript::RunCmd256 - pclose(fp) failed(errno: %d)", errno);
            return -12;
        }

        // 在ARM板上子跑的时候，会出现僵尸进程
        LOG_DEBUG("CScript::RunCmd256 - 子进程结束状态[%d]，命令返回值[%d]", rc, WEXITSTATUS(rc));
        return 0;
    }

protected:

    inline char* ReadCmd(const char* path) {
        FILE* fpr = fopen(path, "r");
        char* cmd = NULL;
        if (fpr) {
            fseek(fpr, 0, SEEK_END);
            long sz = ftell(fpr); rewind(fpr);
            cmd = (char*)malloc(sz + 1);
            if (cmd) {
                int rc = fread(cmd, sz, 1, fpr);
                if (rc <= 0) {
                    free(cmd);
                    cmd = NULL;
                }
            } fclose(fpr);
        } return cmd;
    }
};

#endif  //!SCRIPT_HPP_INCLUDE
