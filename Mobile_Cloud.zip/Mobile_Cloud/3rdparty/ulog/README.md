# ulog
tiny log libary for c

## Usage

add `ulog.h` and `ulog.c` into your project, and include `ulog.h`, then
using macros `LOG_TRACE`, `LOG_DEBUG`, `LOG_INFO`, `LOG_WARN`, `LOG_ERROR` to log.

If you need configure the output, see comments in `ulog.h` and function `ulog_init`.
