#ifndef ULOG_UTILS_H
#define ULOG_UTILS_H

#include "ulog.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __cplusplus
extern "C" {
#endif

    // export ULOG_LEVEL=0
    // echo $ULOG_LEVEL
    // unset ULOG_LEVEL

    int ulog_setenv(int level, const char* logdir);
    // init ulog with default configuration. return if init OK. 1 => ok, 0 => error.
    // will log to stdout and a log file in current work directory(If ENV var ULOG_DIR set to a directory, then use it).
    // app: argv[0] program name, using for log file name. 'app.log.date_time'
    // using filter if ENV var ULOG_LEVEL set Trace/Debug/Info/Warn/Error.
    int ulog_init_default(const char* app);

#ifdef __cplusplus
}
#endif
#endif // ULOG_UTILS_H
