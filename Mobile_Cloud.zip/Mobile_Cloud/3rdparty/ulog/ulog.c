#include <stdio.h>
#include <stdarg.h>
#include "ulog.h"

//////////////////////////////////////////////////////////////////
#if ULOG_ENABLE_TIME
# ifdef _WIN32
# include "windows.h"
# endif

void ulog_gettime(time_t* tv_sec, long* tv_nsec) {
# ifdef _WIN32
    __int64 t = 0;
    GetSystemTimeAsFileTime((FILETIME*)&t);
    t -= 116444736000000000ll;       // 1601-01-01 ~ 1970-01-01
    *tv_sec = t / 10000000ll;        // seconds
    *tv_nsec = t % 10000000ll * 100; // nano
# else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    *tv_nsec = ts.tv_nsec;
    *tv_sec = ts.tv_sec;
# endif
}
#endif

#define COLOR_ADDR  "\x1b[90m"
#define COLOR_FUNC  COLOR_ADDR
#define COLOR_TIME  "\x1b[92m"
#define COLOR_RESET "\x1b[0m"

static const char* const TAG_NAMES[] = {
    [ULOG_TAG_TRACE] = "[TRACE]",
    [ULOG_TAG_DEBUG] = "[DEBUG]",
    [ULOG_TAG_INFO] = "[INFO ]",
    [ULOG_TAG_WARN] = "[WARN ]",
    [ULOG_TAG_ERROR] = "[ERROR]",
};

static const char* const TAG_COLORS[] = {
    [ULOG_TAG_TRACE] = "\x1b[94m",
    [ULOG_TAG_DEBUG] = "\x1b[36m",
    [ULOG_TAG_INFO] = "\x1b[32m",
    [ULOG_TAG_WARN] = "\x1b[33m",
    [ULOG_TAG_ERROR] = "\x1b[31m",
};

//////////////////////////////////////////////////////////////////
// ulog default print function, just print to stdout
static int ulog_default_print(void* userdata, int tag, const char* line) {
    return printf("%s", line);
}

static struct ulog_variables
{
    int flt;
    print_func func;
    void* ctx;
} glob_ulogvar = {
    .ctx = NULL,
    .flt = ULOG_LV_ALL,
    .func = ulog_default_print
};

void ulog_log(int tag,
    const char* file, int lineno,
    const char* func, const char* format, ...) {

    const char* p; int idx = 0;
    char line[ULOG_LINE_MAXCHAR];
    // ignore log tag not in filters
    if (!(tag & glob_ulogvar.flt)) {
        return;
    }

#if ULOG_ENABLE_ADDR
    // get file name from file path
    for (p = file; *p; p++) {
        if (*p == '/' ||
            *p == '\\') {
            file = p + 1;
        }
    }
#endif

#if ULOG_ENABLE_TIME
    // prcess timestamp, tag name, address, function get timestamp
    time_t tv_sec; long tv_nsec = 0;
    ulog_gettime(&tv_sec, &tv_nsec);
    struct tm* ttt = localtime(&tv_sec);
# if ULOG_ENABLE_COLOR
    idx += snprintf(line + idx, sizeof(line) - idx, "%s", COLOR_TIME);
# endif

# if ULOG_ENABLE_DATE
    idx += strftime(line + idx, sizeof(line) - idx, "%Y-%m-%d %H:%M:%S", ttt);
# else
    idx += strftime(line + idx, sizeof(line) - idx, "%H:%M:%S", ttt);
# endif

# if ULOG_ENABLE_MILLISECOND
    idx += snprintf(line + idx, sizeof(line) - idx, ".%03ld", tv_nsec / 1000000L);
# endif
#endif

#if ULOG_ENABLE_COLOR
    idx += snprintf(line + idx, sizeof(line) - idx, " %s%s", TAG_COLORS[tag], TAG_NAMES[tag]);
#else
    idx += snprintf(line + idx, sizeof(line) - idx, " %s", TAG_NAMES[tag]);
#endif

#if ULOG_ENABLE_ADDR
# if ULOG_ENABLE_COLOR
    idx += snprintf(line + idx, sizeof(line) - idx, " %s%s:%d", COLOR_ADDR, file, lineno);
# else
    idx += snprintf(line + idx, sizeof(line) - idx, " %s:%d", file, lineno);
# endif
#endif

#if ULOG_ENABLE_FUNC
# if ULOG_ENABLE_COLOR
    idx += snprintf(line + idx, sizeof(line) - idx, " %s%s", COLOR_FUNC, func);
# else
    idx += snprintf(line + idx, sizeof(line) - idx, " %s", func);
# endif
#endif

#if ULOG_ENABLE_COLOR
    idx += snprintf(line + idx, sizeof(line) - idx, "%s: ", COLOR_RESET);
#else
    idx += snprintf(line + idx, sizeof(line) - idx, ": ");
#endif

    va_list v;
    va_start(v, format);
    idx += vsnprintf(line + idx, sizeof(line) - idx, format, v);
    va_end(v);

    // add new line
    idx += snprintf(line + idx, sizeof(line) - idx, "\n");
    glob_ulogvar.func(glob_ulogvar.ctx, tag, line);
}

void ulog_init(print_func func, void* userdata, int filter) {
    glob_ulogvar.func = func ? func : ulog_default_print;
    glob_ulogvar.ctx = userdata;
    glob_ulogvar.flt = filter;
}
