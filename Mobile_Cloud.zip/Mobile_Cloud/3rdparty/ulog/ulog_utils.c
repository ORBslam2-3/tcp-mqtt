#include <time.h>
#include <errno.h>
#include "ulog_utils.h"

static const char* ENV_ULOG_DIR = "ULOG_DIR";
static const char* ENV_ULOG_LEVEL = "ULOG_LEVEL";
int ulog_setenv(int level, const char* logdir) {
    char temp[32]; sprintf(temp, "%d", level);
    // if success return 0, else return -1 
    int rv = setenv(ENV_ULOG_LEVEL, temp, 1);
    if (rv == 0) {
        rv = setenv(ENV_ULOG_DIR, logdir, 1);
    } return rv;
}

static int my_ulog_default_log(void* userdata, int tag, const char* line) {
    int rc = printf("%s", line);
    if (userdata) {
        FILE* fp = (FILE*)userdata;
        fputs(line, fp);
        fflush(fp);
    } return rc;
}

// init ulog with default configuration. return if init OK. 1 => ok, 0 => error.
// will log to stdout and a log file in current work directory(If ENV var ULOG_DIR set to a directory, then use it).
// app: argv[0] program name, using for log file name. 'app.log.date_time'
// using filter if ENV var ULOG_LEVEL set Trace/Debug/Info/Warn/Error.
int ulog_init_default(const char* app) {
    char dir[255] = {'\0'};
    char buf[255], ttt[32]; FILE* fpw;
    int lv = ULOG_LV_ALL; time_t now = 0;
    char* env_lv = getenv(ENV_ULOG_LEVEL);
    char* env_dir = getenv(ENV_ULOG_DIR);
    const char* p = app;
    if (env_lv) {
        if (!strcasecmp(env_lv, "Trace")) {
            lv = ULOG_LV_TRACE;
        } else if (!strcasecmp(env_lv, "Debug")) {
            lv = ULOG_LV_DEBUG;
        } else if (!strcasecmp(env_lv, "Info")) {
            lv = ULOG_LV_INFO;
        } else if (!strcasecmp(env_lv, "Warn")) {
            lv = ULOG_LV_WARN;
        } else if (!strcasecmp(env_lv, "Error")) {
            lv = ULOG_LV_ERROR;
        } else {
            LOG_DEBUG("ulog ENV '%s' = '%s' invalid, using default", ENV_ULOG_LEVEL, env_lv);
            env_lv = (char*)"Trace";
        } LOG_INFO("ulog level=%s", env_lv);
    }

    if (env_dir) {
        snprintf(dir, sizeof(dir) - 1, "%s", env_dir);
        if (dir[strlen(dir) - 1] != CHAR_PATH_SP) {
            dir[strlen(dir) + 1] = 0;
            dir[strlen(dir)] = CHAR_PATH_SP;
        } LOG_DEBUG("ulog dir='%s'", dir);
    }

    for (; *p; p++) {
        if (*p == '/' || *p == '\\') {
            app = p + 1;
        }
    }

    now = time(NULL);
    // 备注：这里改成一个小时内使用同一个日志文件名称，日志内容进行附加
    strftime(ttt, sizeof(ttt), "%Y%m%d.%H", localtime(&now));
    snprintf(buf, sizeof(buf), "%s%s.%s.log", dir, app, ttt);
    fpw = fopen(buf, "a+");
    if (fpw != NULL) {
        LOG_INFO("\nulog create '%s' OK", buf);
        ulog_init(my_ulog_default_log, fpw, lv);
        return 1;
    } else {
        LOG_INFO("ulog create '%s' failed, %s", buf, strerror(errno));
        ulog_init(NULL, NULL, lv);
        return 0;
    }
}
