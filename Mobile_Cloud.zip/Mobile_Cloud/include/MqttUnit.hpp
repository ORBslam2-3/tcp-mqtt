#ifndef MOSQ_CLIENT_HPP
#define MOSQ_CLIENT_HPP

#include "Interface.hpp"
#include <mqtt/include/mosquitto.h>

class CMqttUnit : public CInterface 
{
public:

    //typedef void(*VMSCallback)(const VMS_ChargingDevices&);
    CMqttUnit();
    virtual ~CMqttUnit();
    void Init(FnCanFrameCB func, void* ctx = NULL);
    bool OnHandle(const struct mosquitto_message* message);
    bool Publish(const std::string& dat);
    bool Publish(std::string curTopic,const std::string& dat);

    void SetConnected(int state);
    void Working();

    bool Delete();
    bool ReConnect();
    bool CreateMqtt();

protected:

    mosquitto* mosq;
    std::string sub_topic;
    std::string pub_topic;
   
};

#endif  //!MOSQ_CLIENT_HPP
