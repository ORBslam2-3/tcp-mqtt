#ifndef DATA_UNIT_HPP
#define DATA_UNIT_HPP


#include "MqttUnit.hpp"
#include "MobileCloundCtrl.hpp"

// 业务逻辑部分的数据处理(数据源 + 数据处理)
class CDataUnit
{
public:
    CDataUnit(CMqttUnit& obj);
    virtual ~CDataUnit();

    // 向 服务器 发送数据
    virtual void Working(modbus_t *ctx);

    // 接收 服务器的数据 进行处理
    virtual void Handle(const std::string& dat);

    //VMS_ChargingDevices vms;

    std::uint16_t Interval_C;
    std::uint16_t SCDControlMode;




private:
    int UploadHeartBeat(modbus_t *ctx);

    int UploadDeviceInfo(modbus_t *ctx);

    int UploadChargefault(modbus_t *ctx);

    int UploadScdStatus(modbus_t *ctx);

    int UploadScdCountNum(modbus_t *ctx);

    int UploadBmsInfo(modbus_t *ctx);

    int UploadChargeInfo(modbus_t *ctx);

    int UploadPlatformHeartbeat(modbus_t *ctx);

    CMqttUnit& mqtt;
    CTimeOut<10> timer;
    MobileCloundControl *m_couldControl;
    
    //std::int16_t Interval_C;
};

////////////////////////////////////////////////
#endif  //!DATA_UNIT_HPP
