#ifndef INTERFACE_HPP_INCLUDE
#define INTERFACE_HPP_INCLUDE

#include <string>
#include <vector>
#include <ulog/ulog_utils.h>
#include <ulog/utils/utime.hpp>

struct UserConfig
{
    std::string mqtt_addr;
    unsigned int mqtt_port;
    std::string mqtt_user;
    std::string mqtt_pwd;
    std::string mqtt_topic_sub;
    std::string mqtt_topic_pub;
    //unsigned char secret_type;
    //std::string secret_data;
};

extern const char* topic_sub();
extern const char* topic_pub();
extern struct UserConfig& GetUserConfig();
extern bool LoadConfig(const std::string& fileXML);


enum ECONN : int { eUnkown = -1, eNotConnected, eConnected };
enum ESTEP : int { eCreate = 0, eReConnect, eWorking, eDelete };
typedef void(*FnCanFrameCB)(const std::string& dat, void* ctx);
class CInterface
{
public:
    CInterface();
    virtual ~CInterface();
    virtual void Init(FnCanFrameCB func, void* ctx = NULL) = 0;
    virtual void Working() = 0;
    virtual bool Delete() = 0;

protected:

    void* ctx;
    FnCanFrameCB fun;
    CTimeOut<6> timeOut;
    volatile int state, step;
    void Output(const std::string& dat);
    bool Save(FnCanFrameCB func, void* ctx);
    void UpdateStep(int step) { this->step = step; }
    void UpdateState(int state) { this->state = state; }
};

#endif  //!INTERFACE_HPP_INCLUDE
