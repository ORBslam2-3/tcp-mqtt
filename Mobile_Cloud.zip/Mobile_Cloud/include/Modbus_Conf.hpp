#pragma once
#include <stdio.h>
#ifndef _MSC_VER
#include <unistd.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <libmodbus/install/include/modbus/modbus.h>

struct Device_Id Fetch_Device_Id(modbus_t*ctx);
struct Charger_State Fetch_Charger_State(modbus_t*ctx);
struct Charger_Fault Fetch_Charger_Fault(modbus_t*ctx);
struct SCD_State Fetch_SCD_State(modbus_t*ctx);
struct General_State Fetch_General_State(modbus_t*ctx);
struct SCD_Insert_Number Fetch_SCD_Insert_Number(modbus_t*ctx);
struct BMS_Message Fetch_BMS_Message(modbus_t*ctx);
struct Order_Information Fetch_Order_Information(modbus_t*ctx);
struct ChargingDevices_VMS Fetch_ChargingDevices_VMS(modbus_t *ctx);
struct Terminal_Version Fetch_Terminal_Version(modbus_t*ctx);
struct VMS_ChargingDevices Fetch_VMS_ChargingDevices(modbus_t*ctx);

struct Device_Id
    {        
        unsigned short device_id;

    };

struct Charger_State
    {        
        unsigned short chargerstate;

    };

struct Charger_Fault
    {
        uint16_t chargerfault;

    };

struct SCD_State 
    {
        unsigned short SCDactionstate;
        unsigned short SCDControlstate;
        unsigned short SCDstop;
        unsigned short SCDSOC;         
        unsigned short interesting;

    };

struct General_State
    {
        unsigned short generalstate;

    };

struct SCD_Insert_Number
    {
        unsigned short SCDactiontime;
        unsigned short SCDfailtime;

    };

struct BMS_Message
    {
        uint16_t VIN[9];
        uint16_t VDemand1;
        uint16_t VDemand2;
        uint16_t IDemand1;
        uint16_t IDemand2;
        uint16_t CurrentSoc;
        uint16_t RemainTime;
        uint16_t VMeasure1;
        uint16_t VMeasure2;
        uint16_t IMeasure1;
        uint16_t IMeasure2;

    };

struct Order_Information
    {
        struct Bill_Code
            {
                uint16_t vehicle;
                uint16_t timestamp1;
                uint16_t timestamp2;
            }Bill_code;
                uint16_t StartChargeTimeStamp_Year;
                uint16_t StartChargeTimeStamp_Month;
                uint16_t StartChargeTimeStamp_Day;
                uint16_t StartChargeTimeStamp_Hour;
                uint16_t StartChargeTimeStamp_Minute;
                uint16_t StartChargeTimeStamp_Second;
                uint16_t EndChargeTimeStamp_Year;
                uint16_t EndChargeTimeStamp_Month;
                uint16_t EndChargeTimeStamp_Day;
                uint16_t EndChargeTimeStamp_Hour;
                uint16_t EndChargeTimeStamp_Minute;
                uint16_t EndChargeTimeStamp_Second;
                uint16_t Reason;
                uint16_t Accumulated_charging_capacity1;
                uint16_t Accumulated_charging_capacity2;
                uint16_t BeginMeter1;
                uint16_t BeginMeter2;
                uint16_t EndMeter1;
                uint16_t EndMeter2;
                uint16_t BeginSoc;
                uint16_t EndSoc;

    };

struct ChargingDevices_VMS
    {
            uint16_t interval_p;

    };

struct Terminal_Version
    {
        struct Terminal_Sw_Version
            { 
                uint16_t terminal_sw_version[17];

            }Terminal_sw_version;

        struct Terminal_Hw_Type
            { 
                uint16_t terminal_hw_type[16];

            }Terminal_hw_type;
        
    };

// struct VMS_ChargingDevices
//     {
//         uint16_t SCDControlMode=1;
//         uint16_t Interval_C=2;

//     };

