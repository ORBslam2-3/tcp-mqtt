#ifndef __MQTT_MOBILE_CLOUND_CONTROL__
#define __MQTT_MOBILE_CLOUND_CONTROL__
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string>
#include <thread>
#include <atomic>
#include <chrono>
#include <cstring>
#include "../3rdparty/cJSON/cJSON.hpp"

#include"Modbus_Conf.hpp"
using namespace std;

class MobileCloundControl
{
public:
    MobileCloundControl();

    ~MobileCloundControl();

    int setTenantCode(string tenantCode);

    int setDeviceID(string deviceID);

    int Start();

private:

    int getCurrentTime(tm &iCurrentTime, long &iMilliSecond);

    int getCurTime(char *time, int len);
    
    int getJsonContent(cJSON *root, char *buf,unsigned int size);

public:

    int MakeMessageHead(cJSON *root, int nEnc,string msgType, string serviceType);

    /**
     * @brief 制作心跳包
     *
     * @param isEnc 是否加密
     * @param buf   数据buffer
     * @param bufflen buffer长度
     * @return int 成功0，失败-1
     */

    int MakeHeartBeatTopic(std::string &topic);
    int MakeHeartBeat(short isEnc, string &messageBody,modbus_t *ctx);

    int MakePlatformHeartbeatTopic(std::string &topic);
    int MakePlatformHeartbeat(short isEnc, string &messageBody,modbus_t *ctx);

    int MakeDeviceInfoTopic(string &topic);
    int MakeDeviceInfoMessage(short isEnc, string &messageBody,modbus_t *ctx);

    int MakeChargefaultTopic(string &topic);
    int MakeChargefaultMessage(short isEnc, string &messageBody,modbus_t *ctx);

    int MakeScdStatusTopic(string &topic);
    int MakeScdStatusMessage(short isEnc, string &messageBody,modbus_t *ctx);

    int MakeScdCountNumTopic(string &topic);
    int MakeScdCountNumMessage(short isEnc, string &messageBody,modbus_t *ctx);

    int MakeBmsInfoTopic(string &topic);
    int MakeBmsInfoMessage(short isEnc, string &messageBody,modbus_t *ctx);

    float getFloat(uint16_t value1, uint16_t value2);
    uint32_t Fetch_f(uint16_t t1,uint16_t t2);

    int MakeChargeInfoTopic(string &topic);
    int MakeChargeInfoMessage(short isEnc, string &messageBody,modbus_t *ctx);
  
public:
    string m_tenantCode; //由联通的厂家分配的厂家id
    string m_deviceID;   //设备的唯一id可以是CPUID
    int m_isEnc ;
    
};

#endif