#include "MqttUnit.hpp"
#include <cJSON/cJSON.hpp>
#include "Modbus_Conf.hpp"
# define MOSQ_SUB_QOS 0
# define MOSQ_PUB_QOS 0
///////////////////////////////////////////////////////////////////////////
static void mqtt_msg_cb(struct mosquitto* mosq, void* obj,
    const struct mosquitto_message* message) {
    LOG_DEBUG("mqtt_msg_cb - topic='%s' msg='%.*s'",
        message->topic, message->payloadlen, (char*)message->payload);
    if (message->payload && message->payloadlen > 0) {
        ((CMqttUnit*)obj)->OnHandle(message);

        printf("this is mqtt_msg_cb\n");

    }
}


static void mqtt_connect_cb(struct mosquitto* mosq, void* obj, int rc) {
    if (rc == MOSQ_ERR_SUCCESS) {
        LOG_DEBUG("mqtt_connect_cb - connect server success.");
        ((CMqttUnit*)obj)->SetConnected(ECONN::eConnected);
    } else {
        LOG_ERROR("mqtt_connect_cb - connect server failed(result = %d)", rc);
    }
}


static void mqtt_disconnect_cb(struct mosquitto* mosq, void* obj, int rc) {
    if (rc == MOSQ_ERR_SUCCESS) {
        LOG_DEBUG("mqtt_disconnect_cb - disconnected.");
    } else {
        LOG_ERROR("mqtt_disconnect_cb - disconnected, exception.");
        ((CMqttUnit*)obj)->SetConnected(ECONN::eNotConnected);
    }
}


CMqttUnit::CMqttUnit() : mosq(NULL) {
    if (mosquitto_lib_init() != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit - mosquitto_lib_init() failed");
    }
}


CMqttUnit::~CMqttUnit() {
    CMqttUnit::Delete();
    mosquitto_lib_cleanup();
}


void CMqttUnit::Init(FnCanFrameCB func, void* ctx) {
    CInterface::Save(func, ctx);
    CInterface::UpdateState(ESTEP::eCreate);
    // struct UserConfig& cfg = GetUserConfig();
    this->sub_topic = topic_sub();
    this->pub_topic = topic_pub();
}


bool CMqttUnit::CreateMqtt() {
    struct mosquitto* mosq = mosquitto_new(NULL, true, this);
    if (mosq == NULL) {
        LOG_ERROR("CMqttUnit::CreateMqtt - mosquitto_new() failed");
        return false;
    }

    struct UserConfig& cfg = GetUserConfig();
    mosquitto_message_callback_set(mosq, mqtt_msg_cb);
    mosquitto_connect_callback_set(mosq, mqtt_connect_cb);
    mosquitto_disconnect_callback_set(mosq, mqtt_disconnect_cb);
    mosquitto_username_pw_set(mosq, cfg.mqtt_user.c_str(), cfg.mqtt_pwd.c_str());
    int rc = mosquitto_connect_async(mosq, cfg.mqtt_addr.c_str(), (int)cfg.mqtt_port, 10);
    if (rc != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit::CreateMqtt - mosquitto_connect_async('%s:%d') failed(%s)",
            cfg.mqtt_addr.c_str(), cfg.mqtt_port, mosquitto_strerror(rc));
        mosquitto_destroy(mosq);
        return false;
    }

    // 启动 mosq 事件处理
    rc = mosquitto_loop_start(mosq);
    if (rc != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit::CreateMqtt - mosquitto_loop_start() failed(%s)", mosquitto_strerror(rc));
        mosquitto_disconnect(mosq);
        mosquitto_destroy(mosq);
        return false;
    }

    LOG_DEBUG("CMqttUnit::CreateMqtt - mosquitto create OK.");
    CInterface::UpdateStep(ESTEP::eWorking);
    this->mosq = mosq;
    return true;
}


bool CMqttUnit::Delete() {
    CInterface::UpdateStep(ESTEP::eDelete);
    if (this->mosq) {
        LOG_DEBUG("CMqttUnit::Delete - mosquitto stop and destroy.");
        mosquitto_loop_stop(this->mosq, true);
        mosquitto_disconnect(this->mosq);
        mosquitto_destroy(this->mosq);
    } this->mosq = NULL;
    return true;
}


bool CMqttUnit::ReConnect() {
    if (CInterface::state != ECONN::eNotConnected) {
        LOG_ERROR("CMqttUnit::ReConnect - state error.");
        return false;
    }

    int rc = mosquitto_reconnect(this->mosq);
    if (rc != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit::ReConnect - mosquitto_reconnect() failed(%s)", mosquitto_strerror(rc));
        return false;
    }

    return true;
}


bool CMqttUnit::Publish(const std::string& dat) {
    if (CInterface::state != ECONN::eConnected) {
        if (this->timeOut.TimeOut(2, 3000)) {
            LOG_ERROR("CMqttUnit::Publish - mosquitto not connected.");
        } return false;
    }

    const char* topic = this->pub_topic.c_str();
    int rv = mosquitto_publish(this->mosq, NULL, topic, dat.size(), dat.c_str(), MOSQ_PUB_QOS, false);
    if (rv != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit::Publish - failed (topic: '%s', error: %s)", topic, mosquitto_strerror(rv));
        return false;
    }

    return true;
}

bool CMqttUnit::Publish(std::string curTopic,const std::string& dat) {
    if (CInterface::state != ECONN::eConnected) {
        if (this->timeOut.TimeOut(2, 3000)) {
            LOG_ERROR("CMqttUnit::Publish - mosquitto not connected.");
        } return false;
    }

    const char* topic = curTopic.c_str();
    int rv = mosquitto_publish(this->mosq, NULL, topic, dat.size(), dat.c_str(), MOSQ_PUB_QOS, false);
    if (rv != MOSQ_ERR_SUCCESS) {
        LOG_ERROR("CMqttUnit::Publish - failed (topic: '%s', error: %s)", topic, mosquitto_strerror(rv));
        return false;
    }

    return true;
}


void CMqttUnit::SetConnected(int state) {
    if (state != ECONN::eUnkown) {
        CInterface::state = state;
        if (state == ECONN::eConnected) {
            const char* topic = this->sub_topic.c_str();
            int rv = mosquitto_subscribe(this->mosq, NULL, topic, MOSQ_SUB_QOS);
            if (rv == MOSQ_ERR_SUCCESS) {
                CInterface::UpdateStep(ESTEP::eWorking);
            } else {
                LOG_ERROR("CMqttUnit::SetConnected - subscribe topic '%s' failed: %s", topic, mosquitto_strerror(rv));
            }
        } else {
            CInterface::UpdateStep(ESTEP::eReConnect);
        }
    }
}


bool CMqttUnit::OnHandle(const struct mosquitto_message* message) {
    if (CInterface::state != ECONN::eConnected) {
        LOG_ERROR("CMqttUnit::OnHandle - mosquitto not connected.");
        return false;
    }

    bool is_match = false;
    const char* topic = this->sub_topic.c_str();
    mosquitto_topic_matches_sub(topic, message->topic, &is_match);
    if (!is_match) {
        LOG_ERROR("CMqttUnit::OnHandle - not match(topic: %s, message->topic: %s).", topic, message->topic);
        return false;
    }

    if (message->payload > 0) {
        std::string dat((const char*)message->payload, (int)message->payloadlen);

        //printf("this is OnHandle\n");
        //printf("%s",(const char*)message->payload);
        
        CInterface::Output(dat);
    }

    return true;
}


void CMqttUnit::Working() {
    switch (CInterface::step) {
        case ESTEP::eCreate: {
            if (this->timeOut.TimeOut(0, 5000)) {
                CMqttUnit::CreateMqtt();
                this->timeOut.Update(0);
                this->timeOut.Update(1);
            }
        } break;

        case ESTEP::eReConnect: {
            if (this->timeOut.TimeOut(1, 5000)) {
                CMqttUnit::ReConnect();
                this->timeOut.Update(1);
            }
        } break;

        case ESTEP::eWorking: {
            // do-nothing
        } break;

        default: break;
    }
}
