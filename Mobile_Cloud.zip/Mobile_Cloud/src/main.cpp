#include <signal.h>
#include <unistd.h>
#include "MqttUnit.hpp"
#include "DataUnit.hpp"
//#include "std_msgs/String.h"

#include "Modbus_Conf.hpp"

static volatile bool glob_running = true;

void OnNetDatCB(const std::string &dat, void *ctx)
{
    CDataUnit *data = (CDataUnit *)ctx;
    if (data && glob_running)
    {
        data->Handle(dat);
    }
}


static void signal_handler(int sig_num)
{
    signal(sig_num, signal_handler);
    glob_running = false;
}


int main(int argc, char **argv)
{   
    modbus_t *ctx;
    //创建日志初始化函数
    ulog_init_default(argv[0]);
    signal(SIGTERM, signal_handler);
    signal(SIGINT, signal_handler);

    if (!LoadConfig("Mobile_cloud.xml"))
    {
        return -1;
    }
    CMqttUnit mqtt;
    CDataUnit data(mqtt);
    mqtt.Init(OnNetDatCB, &data);

    //printf("--Interval_C=%d--",data.Interval_C);
    // 初始化ROS节点
    // ros::init(argc, argv, "wxd");
    // // 创建节点句柄

    // ros::NodeHandle n;



    
    ctx = modbus_new_tcp("192.168.43.217", 502);
    modbus_set_debug(ctx, TRUE);

    if (modbus_connect(ctx) == -1)
    {
        fprintf(stderr, "Connection failed: %s\n",
                modbus_strerror(errno));
        modbus_free(ctx);
        return -1;
    }

    
    // 循环等待回调函数
    while (1)
    {

    mqtt.Working();
    data.Working(ctx); 
    }
        

    //data.Working(ctx);
    //ros::spinOnce();
    usleep(100000);
    
    return 0;

    modbus_close(ctx);
    modbus_free(ctx);
}
