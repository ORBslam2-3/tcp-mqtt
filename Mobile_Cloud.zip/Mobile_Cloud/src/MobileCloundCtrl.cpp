
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string>
#include <thread>
#include <atomic>
#include <chrono>
#include <cstring>
#include <sys/time.h>
#include "../3rdparty/cJSON/cJSON.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <fstream>
#include "MobileCloundCtrl.hpp"
//#include "std_msgs/String.h"
#include "ulog/ulog.h"

#include"Modbus_Conf.hpp"

using namespace std;
using namespace std::chrono;


MobileCloundControl::MobileCloundControl()
{

}

MobileCloundControl::~MobileCloundControl()
{

}

int MobileCloundControl::Start()
{
    return 0;
}

int MobileCloundControl::getCurrentTime(tm &iCurrentTime, long &iMilliSecond)
{
    //  X_INFO("%p\n",iCurrentTime);
    timeval tv;
    time_t timep;
    gettimeofday(&tv, NULL); //获取当下精确的s和us的时间
    time(&timep);            //获取从1900年至今的秒数
    iCurrentTime.tm_year += 1900;
    iCurrentTime.tm_mon += 1;
    iMilliSecond = (tv.tv_sec * 1000.0 + tv.tv_usec / 1000.0) - timep * 1000.0; //当前ms数
    return 0;
}



/* Create a bunch of objects as demonstration. */
int MobileCloundControl::getJsonContent(cJSON *root, char *dstBuf, unsigned int size)
{
    /* declarations */
    char *out = NULL;
    char *buf = NULL;
    char *buf_fail = NULL;
    size_t len = 0;
    size_t len_fail = 0;

    /* formatted print */
    out = cJSON_Print(root);

    /* create buffer to succeed */
    len = strlen(out) + 5;
    buf = (char *)malloc(len);
    if (buf == NULL)
    {
        LOG_DEBUG("Failed to allocate memory.\n");
        return -1;
    }

    /* create buffer to fail */
    len_fail = strlen(out);
    buf_fail = (char *)malloc(len_fail);
    if (buf_fail == NULL)
    {
        LOG_DEBUG("Failed to allocate memory.\n");
        free(out);
        return -1;
    }

    /* Print to buffer */
    if (!cJSON_PrintPreallocated(root, buf, (int)len, 1))
    {
        LOG_DEBUG("cJSON_PrintPreallocated failed!\n");
        if (strcmp(out, buf) != 0)
        {
            LOG_DEBUG("cJSON_PrintPreallocated not the same as cJSON_Print!\n");
            LOG_DEBUG("cJSON_Print result:\n%s\n", out);
            LOG_DEBUG("cJSON_PrintPreallocated result:\n%s\n", buf);
        }
        free(out);
        free(buf_fail);
        free(buf);
        return -1;
    }
    /* success */
    if (strlen(buf) < size)
    {
        memcpy(dstBuf, buf, strlen(buf));
    }
    else
    {
        LOG_ERROR("buf size not enough!!!\n");
        free(out);
        free(buf_fail);
        free(buf);
        return -1;
    }
    free(out);
    free(buf_fail);
    free(buf);
    return 0;
}
int MobileCloundControl::getCurTime(char *curtime, int len)
{
    struct tm curTime;
    struct tm *pcurTime = &curTime;
    time_t timep;
    time(&timep);                 //获取从1900年至今的秒数
    pcurTime = localtime(&timep); //注意tm_year和tm_mon的转换后才是实际的时间
    snprintf(curtime, len, "%04d-%02d-%02d:%02d:%02d:%02d", pcurTime->tm_year + 1900, pcurTime->tm_mon + 1, pcurTime->tm_mday, pcurTime->tm_hour, pcurTime->tm_min, pcurTime->tm_sec);
    return 0;
}

//消息头
int MobileCloundControl::MakeMessageHead(cJSON *root, int nEnc,string msgType,string serviceType)
{
    long curMillTime = 0;
    struct tm curTime;
    getCurrentTime(curTime, curMillTime);
    cJSON_AddStringToObject(root, "msgType", msgType.c_str());
    cJSON_AddNumberToObject(root, "encryptFlag", nEnc);
    cJSON_AddItemToObject(root, "reportTime", cJSON_CreateString(to_string(curMillTime).c_str()));
    cJSON_AddStringToObject(root, "serviceType", serviceType.c_str());
    return 0;
}

int MobileCloundControl::MakeHeartBeatTopic(std::string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "deviceHeartbeat";
    return 0;
}
//制作心跳消息
int MobileCloundControl::MakeHeartBeat(short isEnc, string &messageBody,modbus_t *ctx)
{
    /* declare a few. */
    cJSON *root = NULL;
    cJSON *serviceData = NULL;
    char buffer[2048] = {0};
    
    //构建CJSON的数据包r
    root = cJSON_CreateObject();
    MakeMessageHead(root, m_isEnc,"cmsrCloudReq","deviceheartbeat");
    if (isEnc == 0)
    {
        cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());
        //cJSON_AddItemToObject(serviceData, "deviceTime", cJSON_CreateString(day));

        ChargingDevices_VMS ChargingDevices_vms=Fetch_ChargingDevices_VMS(ctx);
        cJSON_AddNumberToObject(serviceData,"interval_p",ChargingDevices_vms.interval_p);

        Terminal_Version Terminal_version=Fetch_Terminal_Version(ctx);

        string Terminal_sw_version="";
        string Terminal_hw_type="";
        for (int i=0;i<16;i++)
        {
            Terminal_sw_version+=to_string(Terminal_version.Terminal_sw_version.terminal_sw_version[i])+".";
            Terminal_hw_type+=to_string(Terminal_version.Terminal_hw_type.terminal_hw_type[i])+".";

        }
    
        cJSON_AddStringToObject(serviceData, "terminal_sw_version",Terminal_sw_version.c_str());
        cJSON_AddStringToObject(serviceData, "terminal_hw_type",Terminal_hw_type.c_str());
        
        getJsonContent(root, buffer, sizeof(buffer));
        messageBody = buffer;
    }
    else
    {
#if 0
        char sm4buf[2048] = {0};
        cJSON * tmpServiceData = cJSON_CreateObject();
        cJSON_AddItemToObject(tmpServiceData, "deviceTime", cJSON_CreateString(day));
        cJSON_AddItemToObject(tmpServiceData, "continuedTime", cJSON_CreateString(to_string(uptime).c_str()));
        cJSON_AddItemToObject(tmpServiceData, "deviceType", cJSON_CreateString("OBU"));
        cJSON_AddItemToObject(tmpServiceData, "deviceSn", cJSON_CreateString(deviceSN.c_str()));
        cJSON_AddItemToObject(tmpServiceData, "deviceStatus", cJSON_CreateString(shorttostring(deviceStatus).c_str()));
        cJSON_AddItemToObject(tmpServiceData, "gnssStatus", cJSON_CreateString(shorttostring(gnssStatus).c_str()));
        getJsonContent(tmpServiceData, sm4buf, sizeof(sm4buf));
        //加密
        //std::cout << sm4buf << endl;
         string enc= m_sm4->encrypt(sm4buf);
         std::cout << enc << endl;
         std::cout << m_sm4->decrypt(enc) << endl;
        //将加密后的数据放入serviceData
        cJSON_AddItemToObject(root, "serviceData",cJSON_CreateString(enc.c_str()));
        cJSON_Delete(tmpServiceData);
#endif
    }
    cJSON_Delete(root);
    return 0;
}

////////////////////////////////////////////////////////////////
int MobileCloundControl::MakePlatformHeartbeatTopic(std::string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "platformHeartbeat";
    return 0;
}

int MobileCloundControl::MakePlatformHeartbeat(short isEnc, string &messageBody,modbus_t *ctx)
{
    /* declare a few. */
    cJSON *root = NULL;
    cJSON *serviceData = NULL;
    char buffer[2048] = {0};

    root = cJSON_CreateObject();
    MakeMessageHead(root, m_isEnc,"jsCloudReq","platformheartbeat");
    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    uint16_t interval_c;
    uint16_t scdControlmode;
    modbus_read_registers(ctx, 0, 1,&interval_c);
    modbus_read_registers(ctx, 1, 1,&scdControlmode);
    cJSON_AddNumberToObject(serviceData,"Interval_C",interval_c);
    cJSON_AddNumberToObject(serviceData,"SCDControlMode",scdControlmode);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;
    
    cJSON_Delete(root);
    return 0;
}


int MobileCloundControl::MakeDeviceInfoTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "deviceInfo";
    return 0;
}
int MobileCloundControl::MakeDeviceInfoMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;
    char buffer[2048] = {0};
    

    //构建CJSON的数据包
    root = cJSON_CreateObject();
    
    MakeMessageHead(root, m_isEnc,"cmsrPlateformReq","deviceInfo");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    Device_Id Device_id = Fetch_Device_Id(ctx);

    cJSON *DeviceInfo=cJSON_CreateObject();
    cJSON_AddNumberToObject(DeviceInfo,"DeviceId",Device_id.device_id); 
    cJSON_AddItemToObject(serviceData,"deviceInfo",DeviceInfo);

    Charger_State Charger_state=Fetch_Charger_State(ctx);
    cJSON_AddNumberToObject(serviceData,"deviceStatus",Charger_state.chargerstate);

    General_State General_state=Fetch_General_State(ctx);
    cJSON_AddNumberToObject(serviceData,"GeneralState",General_state.generalstate);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}

int MobileCloundControl::MakeChargefaultTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "chargefault";
    return 0;
}

int MobileCloundControl::MakeChargefaultMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;

    char buffer[2048] = {0};


    //构建CJSON的数据包
    root = cJSON_CreateObject();
 
    MakeMessageHead(root, m_isEnc, "cmsrPlateformReq","chargefault");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    Charger_Fault Charger_fault=Fetch_Charger_Fault(ctx);
    cJSON_AddNumberToObject(serviceData,"chargerfault",Charger_fault.chargerfault);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}

int MobileCloundControl::MakeScdStatusTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "scdStatus";
    return 0;
}

int MobileCloundControl::MakeScdStatusMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;

    char buffer[2048] = {0};


    //构建CJSON的数据包
    root = cJSON_CreateObject();
    
    MakeMessageHead(root, m_isEnc,"cmsrPlateformReq","scdStatus");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    SCD_State Scd_state=Fetch_SCD_State(ctx);
    cJSON_AddNumberToObject(serviceData,"SCDactionstate",Scd_state.SCDactionstate);
    cJSON_AddNumberToObject(serviceData,"SCDControlstate",Scd_state.SCDControlstate);
    cJSON_AddNumberToObject(serviceData ,"SCDstop",Scd_state.SCDstop);
    cJSON_AddNumberToObject(serviceData,"SCDSOC",Scd_state.SCDSOC);
    cJSON_AddNumberToObject(serviceData,"Water",Scd_state.interesting);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}

int MobileCloundControl::MakeScdCountNumTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "scdCountNum";
    return 0;
}

int MobileCloundControl::MakeScdCountNumMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;

    char buffer[2048] = {0};


    //构建CJSON的数据包
    root = cJSON_CreateObject();
    
    MakeMessageHead(root, m_isEnc,"cmsrPlateformReq","scdCountNum");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    SCD_Insert_Number SCD_insert_number=Fetch_SCD_Insert_Number(ctx);
    cJSON_AddNumberToObject(serviceData,"SCDactiontime",SCD_insert_number.SCDactiontime);
    cJSON_AddNumberToObject(serviceData,"SCDfailtime",SCD_insert_number.SCDfailtime);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}

float MobileCloundControl::getFloat(uint16_t value1, uint16_t value2)
{
    float fTemp;
    uint *pTemp=(uint *)&fTemp;
    unsigned int chTemp[4];//a,b,c,d

    chTemp[0]=value1&0xff;
    chTemp[1]=(value1>>8)&0xff;
    chTemp[2]=value2&0xff;
    chTemp[3]=(value2>>8)&0xff;
    //这是ABCD
    //*pTemp=((chTemp[1]<<24)&0xff000000)|((chTemp[0]<<16)&0xff0000)|((chTemp[3]<<8)&0xff00)|(chTemp[2]&0xff);
 
    //这是CDAB
    // *pTemp=((chTemp[3]<<24)&0xff000000)|((chTemp[2]<<16)&0xff0000)|((chTemp[1]<<8)&0xff00)|(chTemp[0]&0xff);
 
    //这是BADC
    //*pTemp=((chTemp[0]<<24)&0xff000000)|((chTemp[1]<<16)&0xff0000)|((chTemp[2]<<8)&0xff00)|(chTemp[3]&0xff);
 
    //这是DCBA
    *pTemp=((chTemp[2]<<24)&0xff000000)|((chTemp[3]<<16)&0xff0000)|((chTemp[0]<<8)&0xff00)|(chTemp[1]&0xff);
    return fTemp;
}

uint32_t MobileCloundControl::Fetch_f(uint16_t t1,uint16_t t2)
    {
        uint8_t a[2]={0};
        a[1]=t2>>8;    //01
        a[0]=t2& 0xff; //00

        uint16_t c=a[0];
        c=c<<8;
        c=c|a[1];

        uint8_t b[2]={0};
        b[1]=t1>>8;    //a0
        b[0]=t1& 0xff; //86

        uint16_t d=b[0];
        d=d<<8;
        d=d|b[1];


        uint32_t f=c;
        f=f<<16;
        f=f|d;
        return f;
    }

int MobileCloundControl::MakeBmsInfoTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "bmsInfo";
    return 0;
}

int MobileCloundControl::MakeBmsInfoMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;

    char buffer[2048] = {0};


    //构建CJSON的数据包
    root = cJSON_CreateObject();
    
    MakeMessageHead(root, m_isEnc,"cmsrPlateformReq","bmsInfo");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());


    BMS_Message BMS_message=Fetch_BMS_Message(ctx);
    string sVIN="";
    for (int i=0;i<9;i++)
    {
        sVIN+=to_string(BMS_message.VIN[i])+"-";
    }
    cJSON_AddStringToObject(serviceData,"VIN",sVIN.c_str());

    float VDemand=getFloat(BMS_message.VDemand1, BMS_message.VDemand2);
    cJSON_AddNumberToObject(serviceData,"VDemand",VDemand);

    float IDemand=getFloat(BMS_message.IDemand1, BMS_message.IDemand2);
    cJSON_AddNumberToObject(serviceData,"IDemand",IDemand);

    cJSON_AddNumberToObject(serviceData,"CurrentSoc",BMS_message.CurrentSoc);
    cJSON_AddNumberToObject(serviceData,"RemainTime",BMS_message.RemainTime);

    float VMeasure=getFloat(BMS_message.VMeasure1, BMS_message.VMeasure2);
    cJSON_AddNumberToObject(serviceData,"VMeasure",VMeasure);

    float IMeasure=getFloat(BMS_message.IMeasure1, BMS_message.IMeasure2);
    cJSON_AddNumberToObject(serviceData,"IMeasure", IMeasure);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}


int MobileCloundControl::MakeChargeInfoTopic(string &topic)
{
    topic = "cmsr/s2/" + m_tenantCode + "/" + m_deviceID + "/" + "chargeInfo";
    return 0;
}

int MobileCloundControl::MakeChargeInfoMessage(short isEnc, string &messageBody,modbus_t *ctx)
{
    cJSON *root = NULL;
    cJSON *serviceData = NULL;

    char buffer[2048] = {0};


    //构建CJSON的数据包
    root = cJSON_CreateObject();
    
    MakeMessageHead(root, m_isEnc,"cmsrPlateformReq", "chargeInfo");

    cJSON_AddItemToObject(root, "serviceData", serviceData = cJSON_CreateObject());

    Order_Information Order_information=Fetch_Order_Information(ctx);
    string betime=to_string(Order_information.StartChargeTimeStamp_Year)+"/"+to_string(Order_information.StartChargeTimeStamp_Month)
    +"/"+to_string(Order_information.StartChargeTimeStamp_Day)+":"+to_string(Order_information.StartChargeTimeStamp_Hour)
    +":"+to_string(Order_information.StartChargeTimeStamp_Minute)+":"+to_string(Order_information.StartChargeTimeStamp_Second);

    string endtime=to_string(Order_information.EndChargeTimeStamp_Year)+"/"+to_string(Order_information.EndChargeTimeStamp_Month)
    +"/"+to_string(Order_information.EndChargeTimeStamp_Day)+":"+to_string(Order_information.EndChargeTimeStamp_Hour)
    +":"+to_string(Order_information.EndChargeTimeStamp_Minute)+":"+to_string(Order_information.EndChargeTimeStamp_Second);
    
    cJSON *Billcode=cJSON_CreateObject();
    cJSON_AddNumberToObject(Billcode,"vehicle",Order_information.Bill_code.vehicle); 

    uint32_t Timestamp=Fetch_f(Order_information.Bill_code.timestamp1,Order_information.Bill_code.timestamp2);    
    cJSON_AddNumberToObject(Billcode,"timestamp", Timestamp*0.001);

    cJSON_AddItemToObject(serviceData,"BillCode",Billcode);

    cJSON_AddStringToObject(serviceData,"StartChargeTime",betime.c_str());
    
    cJSON_AddStringToObject(serviceData,"EndChargeTime",endtime.c_str());

    cJSON_AddNumberToObject(serviceData,"Reason",Order_information.Reason);

    uint32_t Accumulated_charging_capacity=Fetch_f(Order_information.Accumulated_charging_capacity1,Order_information.Accumulated_charging_capacity2);
    cJSON_AddNumberToObject(serviceData,"Accumulated_charging_capacity", Accumulated_charging_capacity*0.001);

    
    uint32_t BeginMeter=Fetch_f(Order_information.BeginMeter1,Order_information.BeginMeter2);
    cJSON_AddNumberToObject(serviceData,"BeginMeter", BeginMeter*0.001);

    uint32_t EndMeter=Fetch_f(Order_information.EndMeter1,Order_information.EndMeter2);
    cJSON_AddNumberToObject(serviceData,"EndMeter", EndMeter*0.001);


    cJSON_AddNumberToObject(serviceData,"BeginSoc",Order_information.BeginSoc);
    cJSON_AddNumberToObject(serviceData,"EndSoc",Order_information.EndSoc);

    getJsonContent(root, buffer, sizeof(buffer));
    messageBody = buffer;

    return 0;
}











int MobileCloundControl::setTenantCode(string tenantCode)
{
    m_tenantCode = tenantCode;
    return 0;
}
int MobileCloundControl::setDeviceID(string deviceID)
{
    m_deviceID = deviceID;
    return 0;
}
