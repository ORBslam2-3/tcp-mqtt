#include"Modbus_Conf.hpp"
#include<iostream>



//test writer holding-registers  and  read   

#define SERVER_ID       1
#define ADDRESS_START   0
#define ADDRESS_END     134




struct Device_Id Fetch_Device_Id(modbus_t*ctx)
    {
        Device_Id Device_id;
        modbus_read_input_registers(ctx, 0, 1, &Device_id.device_id);
       // printf("Device_id=%x\n",Device_id.device_id);
        return Device_id;
    }

struct Charger_State Fetch_Charger_State(modbus_t*ctx)
    {
        Charger_State Charger_st;
        modbus_read_input_registers(ctx, 13, 1, &Charger_st.chargerstate);
        //printf("chargerstate=%d\n",Charger_st.chargerstate);
        return Charger_st;
    }

struct Charger_Fault Fetch_Charger_Fault(modbus_t*ctx)
    {
        Charger_Fault Charger_f;
        modbus_read_input_registers(ctx, 14, 1, &Charger_f.chargerfault);
        //printf("chargerfault=%d\n",Charger_f.chargerfault);
        return Charger_f;
    }

struct SCD_State Fetch_SCD_State(modbus_t*ctx)
    {
        SCD_State Scd_st;
        modbus_read_input_registers(ctx, 15, 5, &Scd_st.SCDactionstate);
        return Scd_st;
        
    }

struct General_State Fetch_General_State(modbus_t*ctx)
    {
        General_State General_st;
        modbus_read_input_registers(ctx, 20, 1, &General_st.generalstate);
        //printf("GeneralSt.generalstate=%x\n",General_st.generalstate);
        return General_st;
    }

struct SCD_Insert_Number Fetch_SCD_Insert_Number(modbus_t*ctx)
    {
        SCD_Insert_Number SCD_insert_num;
        modbus_read_input_registers(ctx, 57, 2, &SCD_insert_num.SCDactiontime);
        return SCD_insert_num;

    }

struct BMS_Message Fetch_BMS_Message(modbus_t*ctx)
{
    BMS_Message BMS_mes;
    modbus_read_input_registers(ctx, 59, 19, &BMS_mes.VIN[0]);
    return BMS_mes;
}


struct Order_Information Fetch_Order_Information(modbus_t*ctx)
{
    Order_Information Order_information;
    modbus_read_input_registers(ctx, 78, 24, &Order_information.Bill_code.vehicle);
    return Order_information;

}

struct ChargingDevices_VMS Fetch_ChargingDevices_VMS(modbus_t *ctx)
{
    struct ChargingDevices_VMS ChargingDevices_vms;
    modbus_read_input_registers(ctx, 102, 1, &ChargingDevices_vms.interval_p);
    //printf("interval_p=%x\n",Obj.interval_p);
    return ChargingDevices_vms;
}

struct Terminal_Version Fetch_Terminal_Version(modbus_t*ctx)
{
    Terminal_Version Terminal_version;  //函数体内部的只是声明一下
    modbus_read_input_registers(ctx, 103, 16, &Terminal_version.Terminal_sw_version.terminal_sw_version[0]);
    modbus_read_input_registers(ctx, 119, 16, &Terminal_version.Terminal_hw_type.terminal_hw_type[0]);
    return Terminal_version;
}


/* 函数里边的 Obj 是在函数体内实例化的一个类似于行参的对象
在函数体内部调用完就会释放，用的时候才会调用
对这个结构体内部的变量进行赋值，modbus_read_input_registers这个函数
就是与结构体建立联系的函数，读的数据就在结构体内部的变量中了
用这个函数时需要在main函数中实例化一个结构体对象来接收。。。。。*/

