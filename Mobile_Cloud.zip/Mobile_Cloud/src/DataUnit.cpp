#include "DataUnit.hpp"
#include "../3rdparty/ulog/ulog.h"
#include <tsm4/tsm4.hpp>
#include "../3rdparty/ulog/ulog.h"


CDataUnit::CDataUnit(CMqttUnit& obj) : mqtt(obj) {
   m_couldControl=new  MobileCloundControl();
   m_couldControl->setTenantCode("{tenantCode}");
   m_couldControl->setDeviceID("{deviceId}");
   m_couldControl->Start();
}


CDataUnit::~CDataUnit() {


}

int CDataUnit::UploadHeartBeat(modbus_t *ctx)
{
    std::string messageBody;
    string heartBeatInfoTopic;
     m_couldControl->MakeHeartBeatTopic(heartBeatInfoTopic);
     m_couldControl->MakeHeartBeat(0,messageBody,ctx);
    this->mqtt.Publish(heartBeatInfoTopic,messageBody);
    LOG_INFO("topic is %s\n", heartBeatInfoTopic.c_str());
    return 0;

}

int CDataUnit::UploadDeviceInfo(modbus_t *ctx)
{
    std::string messageBody;
    string deviceInfoTopic;
    m_couldControl->MakeDeviceInfoTopic(deviceInfoTopic);
    m_couldControl->MakeDeviceInfoMessage(0,messageBody,ctx);
    this->mqtt.Publish(deviceInfoTopic,messageBody);
    LOG_INFO("topic is %s\n", deviceInfoTopic.c_str());
    return 0;
}

int CDataUnit::UploadChargefault(modbus_t *ctx)
{
    std::string messageBody;
    string chargefaultTopic;
    m_couldControl->MakeChargefaultTopic(chargefaultTopic);
    m_couldControl->MakeChargefaultMessage(0,messageBody,ctx);
    this->mqtt.Publish(chargefaultTopic,messageBody);
    LOG_INFO("topic is %s\n", chargefaultTopic.c_str());
    return 0;
}

int CDataUnit::UploadScdStatus(modbus_t *ctx)
{
    std::string messageBody;
    string scdStatusTopic;
    m_couldControl->MakeScdStatusTopic(scdStatusTopic);
    m_couldControl->MakeScdStatusMessage(0,messageBody,ctx);
    this->mqtt.Publish(scdStatusTopic,messageBody);
    LOG_INFO("topic is %s\n", scdStatusTopic.c_str());
    return 0;
}

int CDataUnit::UploadScdCountNum(modbus_t *ctx)
{
    std::string messageBody;
    string scdCountNumTopic;
    m_couldControl->MakeScdCountNumTopic(scdCountNumTopic);
    m_couldControl->MakeScdCountNumMessage(0,messageBody,ctx);
    this->mqtt.Publish(scdCountNumTopic,messageBody);
    LOG_INFO("topic is %s\n", scdCountNumTopic.c_str());
    return 0;
}

int CDataUnit::UploadBmsInfo(modbus_t *ctx)
{
    std::string messageBody;
    string bmsInfoTopic;
    m_couldControl->MakeBmsInfoTopic(bmsInfoTopic);
    m_couldControl->MakeBmsInfoMessage(0,messageBody,ctx);
    this->mqtt.Publish(bmsInfoTopic,messageBody);
    LOG_INFO("topic is %s\n", bmsInfoTopic.c_str());
    return 0;
}

int CDataUnit::UploadChargeInfo(modbus_t *ctx)
{
    std::string messageBody;
    string chargeInfoTopic;
    m_couldControl->MakeChargeInfoTopic(chargeInfoTopic);
    m_couldControl->MakeChargeInfoMessage(0,messageBody,ctx);
    this->mqtt.Publish(chargeInfoTopic,messageBody);
    LOG_INFO("topic is %s\n", chargeInfoTopic.c_str());
    return 0;
}

int CDataUnit::UploadPlatformHeartbeat(modbus_t *ctx)
{
    std::string messageBody;
    string platformHeartbeatTopic;
    m_couldControl->MakePlatformHeartbeatTopic(platformHeartbeatTopic);
    m_couldControl->MakePlatformHeartbeat(0,messageBody,ctx);
    this->mqtt.Publish(platformHeartbeatTopic,messageBody);
    LOG_INFO("topic is %s\n", platformHeartbeatTopic.c_str());
    return 0;
}





void CDataUnit::Working(modbus_t *ctx) {


    //解析数据后写到了保持寄存器里
    if (this->timer.TimeOut(0, 1000)) {
        modbus_write_registers(ctx, 0, 1,&this->SCDControlMode);
        modbus_write_registers(ctx, 1, 1,&this->Interval_C);
    }

    //上报写入保持寄存器的数字---即上报状态
    if (this->timer.TimeOut(1, 2000)) {
        UploadPlatformHeartbeat(ctx);
    }


    //上报任务3: 获取数据&上报
    if (this->timer.TimeOut(2, 3000)) {
        UploadHeartBeat(ctx);
    }

    if (this->timer.TimeOut(3, 4000)) {
        UploadDeviceInfo(ctx);
    }

    if (this->timer.TimeOut(4, 5000)) {
        UploadChargefault(ctx);
    }

    if (this->timer.TimeOut(5, 6000)) {
        UploadScdStatus(ctx);
    }

    if (this->timer.TimeOut(6, 7000)) {
        UploadScdCountNum(ctx);
    }

    if (this->timer.TimeOut(7, 8000)) {
        UploadBmsInfo(ctx);
    }

    if (this->timer.TimeOut(8, 9000)) {
        UploadChargeInfo(ctx);
    }

    

}


void CDataUnit::Handle(const std::string& dat) {


    //数据传输到dat里边了，可以直接在这里解析

    char *data=(char*)dat.c_str();

    cJSON * root = cJSON_Parse(data);
    if(!root) {
        printf("no json\n");
    }

    cJSON *Interval_c = cJSON_GetObjectItem(root, "Interval_C");
    if (!Interval_C) {
    printf("no Interval_C!\n");
    } else{
        printf("--%d--",Interval_c->valueint);
    }

    cJSON *SCDControlmode = cJSON_GetObjectItem(root, "SCDControlMode");
    if (!SCDControlmode) {
    printf("no SCDControlMode!\n");
    } else{
        printf("--%d--",SCDControlmode->valueint);
    }

    this->Interval_C=Interval_c->valueint;
    this->SCDControlMode=SCDControlmode->valueint;

    printf("Handle->成功\n");




}

