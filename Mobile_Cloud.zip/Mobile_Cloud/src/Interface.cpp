#include "Interface.hpp"
#include <txml/xml_wrap.hpp>
#include <txml/xml_path.hpp>


static UserConfig glob_userconfig;

struct UserConfig& GetUserConfig() { return glob_userconfig; }
bool LoadConfig(const std::string& fileXML) {
    CXmlWrap aXml(CXmlPath::GetPathName2(fileXML));
    if (!aXml.IsOpened()) {
        return false;
    }

    XMLElement* mqtt = aXml.Route("Mobile/mqtt");
    if (!mqtt) {
        return false;
    }

    glob_userconfig.mqtt_addr = aXml.GetValue<std::string>(mqtt, "addr", "");
    glob_userconfig.mqtt_port = aXml.GetValue<unsigned int>(mqtt, "port", 1883);
    glob_userconfig.mqtt_user = aXml.GetValue<std::string>(mqtt, "user", "");
    glob_userconfig.mqtt_pwd = aXml.GetValue<std::string>(mqtt, "pwd", "");
    glob_userconfig.mqtt_topic_pub = aXml.GetValue<std::string>(mqtt, "topic_pub", "");
    glob_userconfig.mqtt_topic_sub = aXml.GetValue<std::string>(mqtt, "topic_sub", "");
    return true;
}


const char* topic_sub() {
    return glob_userconfig.mqtt_topic_sub.c_str();
}

const char* topic_pub() {
    return glob_userconfig.mqtt_topic_pub.c_str();
}

CInterface::CInterface() {
    this->step = ESTEP::eCreate;
    this->state = ECONN::eUnkown;
    this->fun = NULL;
    this->ctx = NULL;
}


CInterface::~CInterface() {
    this->fun = NULL;
    this->ctx = NULL;
}


bool CInterface::Save(FnCanFrameCB func, void* ctx) {
    if (func) {
        this->ctx = ctx;
        this->fun = func;

        //printf("this is 1\n");
        return true;
    } else {
        return false;
    }
}


void CInterface::Output(const std::string& dat) {
    if (this->fun) {
        this->fun(dat, ctx);
        
        //printf("this is Output\n");
        
    }
 }
